package model;

public interface StaffDetail extends PersonDetail{

	public void displayPassword();
	public void displayShift();
}
