package model;

public class Medicine {
	
	private String medicineName;
	private String time;
	private int dose;
	
	public Medicine(String mn, String t, int d) {
		this.medicineName = mn;
		this.time = t;
		this.dose = d;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getDose() {
		return dose;
	}

	public void setDose(int dose) {
		this.dose = dose;
	}
}
