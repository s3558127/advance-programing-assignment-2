package controller;

public class MenuPage {

}
