package model;

public interface PersonDetail {
	
	public void displayId();
}
