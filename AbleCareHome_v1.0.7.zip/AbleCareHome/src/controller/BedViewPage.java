package controller;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class BedViewPage {

	@FXML
	private Button back;
	@FXML
	private Button patientConfigurationButton;
	
	@FXML
	Main m = new Main();
	
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		m.changeScene("/fxml/MenuPage.fxml");
	}
	
	@FXML
	public void patientConfiguration(ActionEvent event) throws IOException{
		m.changeScene("/fxml/PatientConfigurationPage.fxml");
	}
	
}
