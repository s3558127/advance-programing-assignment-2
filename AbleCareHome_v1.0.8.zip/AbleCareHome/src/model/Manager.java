package model;

public class Manager {
	
	private String id;
	
	public Manager(String id) {
		this.id=id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
