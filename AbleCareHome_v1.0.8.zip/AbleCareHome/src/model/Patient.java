package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Patient implements PatientDetail {
	
	private String id;
	private String firstname;
	private String lastname;
	private String username;
	private char gender;

	private ArrayList<Prescription> prescriptionList;
	private ArrayList<Medicine> medicineList;
	public Patient(String id, String fn, String ln, String un, char g){
		this.id = id;
		this.firstname = fn;
		this.lastname = ln;
		this.username = un;
		this.gender = g;
		medicineList = new ArrayList<Medicine>();
		prescriptionList = new ArrayList<Prescription>();
	}
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	
	public ArrayList<Medicine> getMedicineList() {
		return medicineList;
	}

	public void setMedicineList(ArrayList<Medicine> medicine) {
		this.medicineList = medicine;
	}
	
	public ArrayList<Prescription> getPrescriptionList() {
		return prescriptionList;
	}

	public void setPrescriptionList(ArrayList<Prescription> prescription) {
		this.prescriptionList = prescription;
	}
	
	@Override
	public void displayId() {
		System.out.println(getId());
	}
	
	@Override
	public void displayMedicine() {
		Iterator<Medicine> medicineIterator = medicineList.iterator();
		while (medicineIterator.hasNext()) {
			System.out.println(medicineIterator.next().getMedicineName());
		}
	}

	@Override
	public void displayPrescription() {
		Iterator<Prescription> prescriptionIterator = prescriptionList.iterator();
		while (prescriptionIterator.hasNext()) {
			System.out.println(prescriptionIterator.next().getPrescription());
		}
	}

}
