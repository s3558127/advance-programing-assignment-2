package model;

public class Prescription {
	
	private String prescription;
	
	public Prescription(String pres) {
		this.prescription = pres;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}
}
