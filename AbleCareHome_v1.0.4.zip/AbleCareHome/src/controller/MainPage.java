package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import app.*;
import model.*;
import java.io.*;

public class MainPage {
	
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private Label invalidDetails;
	@FXML
	private Button loginButton;
	@FXML
	private Button exitButton;
	
	Parent root = null;
	Scene scene = null;
	Stage stage = null;
	
	// collect input data
	@FXML
	private void checkLogin() throws IOException{
		Main m = new Main();
		if(username.getText().isEmpty() || password.getText().isEmpty()) {
			invalidDetails.setText("Please enter username or password!");
		} else if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin123")) {
			m.changeScene("/fxml/MenuPage.fxml");
		} else
			invalidDetails.setText("Wrong username or password!");
	}
	
	// login button
	@FXML
	public void userLogin(ActionEvent event) throws IOException{
		checkLogin();
	}
	
	@FXML
	public void userExit(ActionEvent event) throws IOException{
		stage = (Stage) exitButton.getScene().getWindow();
	    stage.close();
	}
	
}
