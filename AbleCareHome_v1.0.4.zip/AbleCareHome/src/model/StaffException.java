package model;

public class StaffException extends Exception{

	public StaffException(String errorMessage) {
		super(errorMessage);
	}
}
