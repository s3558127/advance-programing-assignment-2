package model;

public class ShiftException extends Exception{
	
	public ShiftException(String errorMessage) {
		super(errorMessage);
	}
}
