package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class ShowBedPatient {
	
	@FXML
	private Label pid;
	@FXML
	private Label username;
	@FXML
	private Label firstname;
	@FXML
	private Label lastname;
	@FXML
	private Label gender;
	@FXML
	private Label medicine;
	@FXML
	private Label prescription;
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	
	String id;
	String patientTarget;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			stmt = con.createStatement();
			String sql = "SELECT patientid FROM showpatient WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				patientTarget = rs.getString("patientid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM patient WHERE pid = '" + patientTarget + "'";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				pid.setText(rs.getString("pid"));
				username.setText(rs.getString("username"));
				firstname.setText(rs.getString("firstname"));
				lastname.setText(rs.getString("lastname"));
				gender.setText(rs.getString("gender"));
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			String f = "Medicine\t\tTime\t\t\tDose";
			medicine.setText("No medicine assigned!");
			stmt = con.createStatement();
			String sql = "SELECT * FROM medicine WHERE pid = '" + patientTarget + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				if (rs.getString("med")!=null) {
					String temp = "\n" + rs.getString("med") + "\t\t\t" + rs.getString("time") + "\t\t" + rs.getString("dose");
					f = f + temp;
					medicine.setText(f);
				}
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			String f = "";
			System.out.println(patientTarget);
			prescription.setText("No prescription assigned!");
			stmt = con.createStatement();
			String sql = "SELECT * FROM prescription WHERE pid = '" + patientTarget + "'";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()) {
				if (rs.getString("prescription")!=null) {
					String temp = "\n" + rs.getString("prescription");
					f = f + temp;
					prescription.setText(f);
				}
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		m.changeScene("/fxml/BedViewPage.fxml");
	}
}
