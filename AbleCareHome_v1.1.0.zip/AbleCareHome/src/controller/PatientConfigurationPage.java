package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class PatientConfigurationPage {
	
	@FXML
	private TextField pidText;
	@FXML
	private TextField medicineText;
	@FXML
	private TextField timeText;
	@FXML
	private TextField doseText;
	@FXML
	private TextField prescriptionText;
	@FXML
	private Label patientid;
	@FXML
	private Label username;
	@FXML
	private Label firstname;
	@FXML
	private Label lastname;
	@FXML
	private Label gender;
	@FXML
	private Label medicine;
	@FXML
	private Label prescription;
	@FXML
	private Button checkButton;
	@FXML
	private Button setMedicineButton;
	@FXML
	private Button setPrescriptionButton;
	@FXML
	private Label invalid;
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	
	String targetPatient = null;
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
    	
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		m.changeScene("/fxml/BedViewPage.fxml");
	}
	
	@FXML
	public void check(ActionEvent event) throws IOException{
		invalid.setText("");
		if(pidText.getText().isEmpty())
			invalid.setText("Please enter username!");
		else
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE pid = '" + pidText.getText() + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					patientid.setText(rs.getString("pid"));
					username.setText(rs.getString("username"));
					firstname.setText(rs.getString("firstname"));
					lastname.setText(rs.getString("lastname"));
					gender.setText(rs.getString("gender"));
					targetPatient = rs.getString("pid");
				
					String f = "";
					prescription.setText("No prescription assigned!");
					stmt = con.createStatement();
					sql = "SELECT * FROM prescription WHERE pid = '" + targetPatient + "'";
					rs = stmt.executeQuery(sql);
					while(rs.next()) {
						if (rs.getString("prescription")!=null) {
							String temp = "\n" + rs.getString("prescription");
							f = f + temp;
							prescription.setText(f);
						}
					}
				
					f = "Medicine\t\tTime\t\t\tDose";
					medicine.setText("No medicine assigned!");
					stmt = con.createStatement();
					sql = "SELECT * FROM medicine WHERE pid = '" + targetPatient + "'";
					rs = stmt.executeQuery(sql);
					while(rs.next()) {
						if (rs.getString("med")!=null) {
							String temp = "\n" + rs.getString("med") + "\t\t\t" + rs.getString("time") + "\t\t" + rs.getString("dose");
							f = f + temp;
							medicine.setText(f);
						}
					}
				} else
					invalid.setText("Patient ID doesn't exist!");
			} catch (SQLException exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}

	}
	
	@FXML
	public void setMedicine(ActionEvent event) throws IOException, NumberFormatException, RosterException, StaffException{
		if(targetPatient==null)
			invalid.setText("Please fill in patient id!");
		else if (medicineText.getText().isEmpty() || timeText.getText().isEmpty() || doseText.getText().isEmpty())
			invalid.setText("Please fill in the blank!");
		else {
			start.setMedicine(id, targetPatient, medicineText.getText(), timeText.getText(),Integer.parseInt(doseText.getText()));
			invalid.setText("Added medicine!");
		}
	}
	
	@FXML
	public void setPrescription(ActionEvent event) throws IOException, RosterException, StaffException{
		if(targetPatient==null)
			invalid.setText("Please fill in patient id!");
		else if (prescriptionText.getText().isEmpty())
			invalid.setText("Please fill in the blank!");
		else if (id.charAt(0) == 'd') {
			start.setPrescription(id, targetPatient, prescriptionText.getText());
			invalid.setText("Added prescription");
		}
	}
}