package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Doctor implements StaffDetail{

	private String username;
	private String password;
	private String id;
	private Shift shift;
	
	public Doctor(String id, String un) {
		this.id = id;
		this.username = un;
	}
	
	public String getName() {
		return username;
	}

	public void setName(String name) {
		this.username = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public void setShift(Shift shift) {
		this.shift = shift;
	}
	
	public Shift getShift() {
		return this.shift;
	}
	
	@Override
	public void displayId() {
		System.out.println(getId());
	}
	
	@Override
	public void displayPassword() {
		System.out.println(getPassword());
	}
	
	@Override
	public void displayShift(){
		if (this.shift!=null)
			System.out.println(shift.getStartTime() + " to " + shift.getEndTime());
		else
			System.out.println("No shift allocated yet!");
	}

}
