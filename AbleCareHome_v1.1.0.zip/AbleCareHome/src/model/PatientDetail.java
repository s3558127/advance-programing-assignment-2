package model;

public interface PatientDetail extends PersonDetail{

	public void displayMedicine();
	public void displayPrescription();
}
