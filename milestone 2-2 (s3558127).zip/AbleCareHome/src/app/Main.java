package app;

import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;
import java.io.IOException;
import model.*;


public class Main extends Application {
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		
		// load the FXML file in the view package and use it as the root node
		// in the UI hierarchy
		Parent root = FXMLLoader.load(getClass().getResource("/fxml/Main.fxml"));
		
		// create a scene with a width and height, which can be equal to the width and height of
		// the main pane in our UI
		Scene scene = new Scene(root, 800, 600);
		
		// set the scene on the stage
		primaryStage.setScene(scene);
		
		// show the stage
		primaryStage.show();
		
	}
	
	public static void main(String[] args) throws Exception{
		wardInitialize.main(args);
		Application.launch(args);
	}

}