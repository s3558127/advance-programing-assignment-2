package controller;

import model.Resident;

public class doctorController {
	
	Resident r;
	
	public void initData(Resident r) {
		this.r=r;
	}
	
}
