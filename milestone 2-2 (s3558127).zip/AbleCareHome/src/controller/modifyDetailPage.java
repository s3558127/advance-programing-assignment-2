package controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ChoiceBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import model.*;
import java.util.ArrayList;
import java.io.*;

public class modifyDetailPage {
	
	@FXML private Label invalidDetails;
	
	Resident r;
	
	public void initData(Resident r) {
		this.r=r;
	}
	
	public void setType(String t) {
		r.setType(t);
	}
	
	public void changePassword(String id, String password) {
		if (r.getType().equalsIgnoreCase("Doctor")) {
			ArrayList<Doctor> d = new ArrayList<Doctor>();
			for (int i=0; i<d.size(); i++) {
				if (r.getUserName().equalsIgnoreCase(d.get(i).getUserName())) {
					d.get(i).setDoctorPassword(password);
				}
			}
		} else if (r.getType().equalsIgnoreCase("Nurse")) {
			ArrayList<Nurse> n = new ArrayList<Nurse>();
			for (int i=0; i<n.size(); i++) {
				if (r.getUserName().equalsIgnoreCase(n.get(i).getUserName())) {
					n.get(i).setNursePassword(password);
				}
			}
		} else {
			invalidDetails.setText("A patient may not have a password!");
		}
	}
	
}
