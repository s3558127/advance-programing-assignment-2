package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ChoiceBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import model.*;
import java.util.ArrayList;
import java.io.*;

public class loginPage {
	
	@FXML private TextField usernameField;
	@FXML private PasswordField password;
	@FXML private Label	invalidDetails;
	Resident p = new Resident();
	
	Parent root = null;
	Scene scene = null;
	Stage stage = null;
	
	public void login(ActionEvent event) throws IOException{
		if (usernameField.getText().isEmpty() || password.getText().isEmpty()){
            invalidDetails.setText("Please enter username and password!");
		} else {
			stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            if (checkLogin(stage) == p) {
            	root = FXMLLoader.load(getClass().getResource("/fxml/patientPage.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
		}
	}
	
	
	@FXML private Resident checkLogin(Stage stage) throws IOException{
		// import all database here
		ArrayList<Doctor> d = new ArrayList<Doctor>();
		ArrayList<Nurse> n = new ArrayList<Nurse>();
		ArrayList<Resident> r = new ArrayList<Resident>();
		
		for (int i=0; i<r.size();i++) {
			if ((usernameField.getText().equalsIgnoreCase(r.get(i).getUserName()))) {
				modifyDetailPage m1 = new modifyDetailPage();
				checkDetailPage m2 = new checkDetailPage();
				doctorController m3 = new doctorController();
				nurseController m4 = new nurseController();
				m1.initData(r.get(i));
				m2.initData(r.get(i));
				m3.initData(r.get(i));
				m4.initData(r.get(i));
				for (int j=0; j<d.size(); j++) {
					if (usernameField.getText().equalsIgnoreCase(d.get(j).getUserName())
							&& password.getText().equalsIgnoreCase(d.get(j).getDoctorPassword())) {
						Doctor dd = new Doctor();
						dd = d.get(j);
						root = FXMLLoader.load(getClass().getResource("/fxml/doctorPage.fxml"));
                        scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                        return dd;
					}
				}
				for (int k=0; k<n.size(); k++) {
					if (usernameField.getText().equalsIgnoreCase(n.get(k).getUserName())
						&& password.getText().equalsIgnoreCase(n.get(k).getNursePassword())) {
						Nurse nn = new Nurse();
						nn = n.get(k);
						root = FXMLLoader.load(getClass().getResource("/fxml/nursePage.fxml"));
                        scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                        return nn;
					}
				}
				return p;
			} else {
				invalidDetails.setText("Account doens't exist!");
			}
		}
		return null;
	}
	
}
