package controller;

import model.Resident;

public class checkDetailPage {
	
	Resident r;
	
	public void initData(Resident r) {
		this.r=r;
	}
}
