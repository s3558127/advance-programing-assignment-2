package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ChoiceBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import model.*;

public class signUp {
	
	@FXML private TextField idField;
	@FXML private TextField firstnameField;
	@FXML private TextField lastnameField;
	@FXML private TextField usernameField;
	@FXML private ChoiceBox<String> typeBox;
	@FXML private ChoiceBox<String> genderBox;
	@FXML private ChoiceBox<String> shiftBox;
	@FXML private Label invalidDetails;
	@FXML private PasswordField password1;
	@FXML private PasswordField password2;
	
	ObservableList<String> typeBoxList = FXCollections.observableArrayList("Patient", "Doctor", "Nurse");
	ObservableList<String> genderBoxList = FXCollections.observableArrayList("Male", "Female");
	ObservableList<String> shiftBoxList = FXCollections.observableArrayList("8am to 4pm", "2pm to 10pm");
	
	Parent root = null;
	Scene scene = null;
	Stage stage = null;
	
	@FXML public void initialize() {
		typeBox.setItems(typeBoxList);
		genderBox.setItems(genderBoxList);
		shiftBox.setItems(shiftBoxList);
	}
	
	@FXML public void signupProceed(ActionEvent actionEvent) {
		
		if(idField.getText().isEmpty()||firstnameField.getText().isEmpty()||lastnameField.getText().isEmpty()
			||usernameField.getText().isEmpty()||typeBox.getValue().isEmpty()||genderBox.getValue().isEmpty()) {
			invalidDetails.setText("Please fill in all the details!");
		} else if (!password1.getText().equalsIgnoreCase(password2.getText())) {
			invalidDetails.setText("Password mismatch!");
		} else {
			if (typeBox.getValue().equals("Doctor")) {
				Doctor d = new Doctor();
				d.setID(idField.getText());
				d.setFirstName(firstnameField.getText());
				d.setLastName(lastnameField.getText());
				d.setUserName(usernameField.getText());
				d.setType(typeBox.getValue());
				d.setGender(genderBox.getValue());
				d.setDoctorName(usernameField.getText());
				d.setDoctorPassword(password1.getText());
				d.setDoctorShift(null);
			} else if (typeBox.getValue().equals("Nurse")) {
				Nurse n = new Nurse();
				n.setID(idField.getText());
				n.setFirstName(firstnameField.getText());
				n.setLastName(lastnameField.getText());
				n.setUserName(usernameField.getText());
				n.setType(typeBox.getValue());
				n.setGender(genderBox.getValue());
				n.setNurseID(usernameField.getText());
				n.setNursePassword(password1.getText());
				n.setNurseShift(null);
			} else {
				Resident r = new Resident();
				r.setID(idField.getText());
				r.setFirstName(firstnameField.getText());
				r.setLastName(lastnameField.getText());
				r.setUserName(usernameField.getText());
				r.setType(typeBox.getValue());
				r.setGender(genderBox.getValue());
			}
		}
	}
}
