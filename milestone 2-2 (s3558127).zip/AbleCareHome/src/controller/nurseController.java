package controller;

import model.Resident;

public class nurseController {

	Resident r;
	
	public void initData(Resident r) {
		this.r=r;
	}
	
}
