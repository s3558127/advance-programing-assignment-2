package controller;

public class adminPage {

}
