package model;

import static org.junit.Assert.*;
import org.junit.Test;

public class Test1 {
	wardInitialize w = new wardInitialize();

	@Test
	public void testSetNurseShift() throws ShiftException{
		w.setNurseShift(null, 0);
	}
	
	@Test
	public void testPutResidentBed(){
		w.putResidentBed(null, null, null);
	}
	
	@Test
	public void testMoveResidentToBed(){
		w.moveResidentBed(null, null, null, 0);;
	}
	
	@Test
	public void testShowResidentDetialOnBed() throws RoleException{
		w.showResidentDetialOnBed(null, 0);
	}
	
	@Test
	public void testSetPatientMedicine() throws RoleException{
		w.setPatientMedicine(null, null, null, 0, null);
	}
	
	@Test
	public void testSetPatientPrescription() throws RoleException{
		w.setPatientPrescription(null, null, 0);
	}
	
	@Test
	public void testSetType(){
		w.setType(null, null);
	}
}
