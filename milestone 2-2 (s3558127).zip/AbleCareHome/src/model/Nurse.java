package model;

public class Nurse extends Resident{
	private String nurseID;
	private String password;
	private Shift shift;
	
	public Nurse() {
	}
	
	public Nurse(String nurseID, String password, Shift shift) {
		this.nurseID=nurseID;
		this.password=password;
		this.shift=shift;
	}
	
	public String getNurseID() {
		return this.nurseID;
	}
	
	public String getNursePassword() {
		return this.password;
	}
	
	public Shift getNurseShift() {
		return this.shift;
	}
	
	public void setNurseID(String n) {
		this.nurseID=n;
	}
	
	public void setNursePassword(String p) {
		this.password=p;
	}
	
	public void setNurseShift(Shift s) {
		this.shift=s;
	}
	
}
