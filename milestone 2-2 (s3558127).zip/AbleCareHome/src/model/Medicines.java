package model;

public class Medicines {
	private String medName;
	private String pres;
	private String time;
	private int dose;
	public Medicines(String medName, String pres, String time, int dose) {
		this.medName=medName;
		this.pres=pres;
		this.time=time;
		this.dose=dose;
	}
	
	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getDose() {
		return dose;
	}

	public void setDose(int dose) {
		this.dose = dose;
	}

	public String getMedicineName() {
		return medName;
	}
	public void setMedicineName(String medName) {
		this.medName = medName;
	}
	public String getPrescription() {
		return pres;
	}
	public void setPrescription(String pres) {
		this.pres = pres;
	}
	
}




