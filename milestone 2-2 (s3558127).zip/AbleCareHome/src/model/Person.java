package model;

public interface Person {
	
	public void displayMedicines();
	public void displayPrescription();
}
