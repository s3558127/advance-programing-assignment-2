package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Resident implements Person{
	
	private ArrayList<Medicines> medicines;
	private ArrayList<Medicines> prescription;
	private ArrayList<Medicines> time;
	private ArrayList<Medicines> dose;
	
	private String ID;
	private String firstName;
	private String lastName;
	private String userName;
	private String type;
	private String gender;
	
	public Resident() {
		medicines=new ArrayList<Medicines>();
		prescription=new ArrayList<Medicines>();
		time=new ArrayList<Medicines>();
		dose=new ArrayList<Medicines>();
	}
	
	Resident(String ID,String firstName, String lastName, String userName, String types, String genders) {
		this.ID=ID;
		this.firstName=firstName;
		this.lastName=lastName;
		this.userName=userName;
		this.gender=genders;
		this.type=types;
	}

	public ArrayList<Medicines> getPrescription() {
		return prescription;
	}

	public void setPrescription(ArrayList<Medicines> prescription) {
		this.prescription = prescription;
	}

	public ArrayList<Medicines> getTime() {
		return time;
	}

	public void setTime(ArrayList<Medicines> time) {
		this.time = time;
	}

	public ArrayList<Medicines> getDose() {
		return dose;
	}

	public void setDose(ArrayList<Medicines> dose) {
		this.dose = dose;
	}

	public ArrayList<Medicines> getMedicines() {
		return medicines;
	}
	
	public void setMedicines(ArrayList<Medicines> medicines) {
		this.medicines = medicines;
	}

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public void displayMedicines() {
		Iterator<Medicines> it = medicines.iterator();
		while (it.hasNext()) {
			System.out.println(it.next().getMedicineName());
		}
	}
	
	public void displayPrescription() {
		Iterator<Medicines> it = prescription.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}