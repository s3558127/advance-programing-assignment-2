package model;

public class Beds {
	
	private int bedNo;
	
	private boolean bedAvailable;
	
	private Resident resident;

	public int getBedNo() {
		return bedNo;
	}

	public void setBedNo(int bedNo) {
		this.bedNo = bedNo;
	}

	public boolean isBedAvailable() {
		return bedAvailable;
	}

	public void setBedAvailable(boolean bedAvailable) {
		this.bedAvailable = bedAvailable;
	}

	public Resident getResident() {
		return resident;
	}

	public void setResident(Resident resident) {
		this.resident = resident;
	}
}
