package model;

public class Doctor extends Resident{
	private String doctorID;
	private String password;
	private Shift shift;
	
	public Doctor() {
	}
	
	Doctor(String doctorID, String password, Shift shift) {
		this.doctorID=doctorID;
		this.password=password;
		this.shift=shift;
	}
	
	
	public String getDoctorID() {
		return this.doctorID;
	}
	
	public String getDoctorPassword() {
		return this.password;
	}
	
	public Shift getDoctorShift() {
		return this.shift;
	}
	
	public void setDoctorID(String n) {
		this.doctorID=n;
	}
	
	public void setDoctorPassword(String p) {
		this.password=p;
	}
	
	public void setDoctorShift(Shift s) {
		this.shift=s;
	}
	
}
