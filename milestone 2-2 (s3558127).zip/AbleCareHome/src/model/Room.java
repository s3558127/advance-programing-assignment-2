package model;

import java.util.ArrayList;

public class Room {

	private int rid;
	
	private boolean isAvailable;
	
	private ArrayList<Beds> beds = new  ArrayList<Beds>();
	
	public int getRoomId() {
		return rid;
	}

	public void setId(int id) {
		this.rid = id;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isOccupied) {
		this.isAvailable = isOccupied;
	}


	public ArrayList<Beds> getBeds() {
		return beds;
	}

	public void setBeds(ArrayList<Beds> beds) {
		this.beds = beds;
	}
	
	
}
