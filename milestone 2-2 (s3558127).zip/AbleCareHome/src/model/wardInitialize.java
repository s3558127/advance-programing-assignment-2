package model;

import java.util.ArrayList;
import java.time.*;
import java.time.format.*;
import java.util.*;

public class wardInitialize {
	
	String logs;
	Scanner scan = new Scanner(System.in);
	public ArrayList<Ward> wardList = new ArrayList<Ward>();
	public ArrayList<Resident> residentList = new ArrayList<Resident>();
	public ArrayList<Doctor> doctorList = new ArrayList<Doctor>();
	public ArrayList<Nurse> nurseList = new ArrayList<Nurse>();
	ArrayList<Medicines> medicineList = new ArrayList<Medicines>();
	public ArrayList<Shift> shiftList = new ArrayList<Shift>();
	public ArrayList<String> logsList = new ArrayList<String>();
	
	public ArrayList<String> getLogsList() {
		return logsList;
	}

	public void setLogsList(ArrayList<String> logsList) {
		this.logsList = logsList;
	}

	public ArrayList<Ward> getWardList() {
		return wardList;
	}
	
	// check details of a resident bed
	public void showResidentDetialOnBed(String sid, int bid) throws RoleException{
		Resident r = new Resident();
		for (int i=0; i<wardList.size();i++) {
			if (!checkDoctorRole(sid) && !checkNurseRole(sid)) {
				throw new RoleException("Not a staff!");
			}
			for (int j=0; j<wardList.get(i).getRoomList().size(); j++) {
				for (int k=0; k<wardList.get(i).getRoomList().get(j).getBeds().size(); k++) {
					if (wardList.get(i).getRoomList().get(j).getBeds().get(k).getBedNo()==bid) {
						r = wardList.get(i).getRoomList().get(j).getBeds().get(k).getResident();
						if (r==null) {
							System.out.println("Bed is not occupied!");
							break;
						}
						System.out.println("ID: " + r.getID());
						System.out.println("First Name: " + r.getFirstName());
						System.out.println("Last Name: " + r.getLastName());
						System.out.println("Username: " + r.getUserName());
						System.out.println("Gender: " + r.getGender());
						System.out.println("Type: " + r.getType());
					}
				}
			}
		}
		logs = sid + "\t" + LocalDateTime.now() + "\tShowing resident details of bed id " + bid ;
		logsList.add(logs);
	}
	
	// setting resident type
	public void setType(String id, String type) {
		Resident r = checkPatientAvailable(id);
		if (r!=null)
			r.setType(type);
	}
	
	// modify staff password
	public void changePassword(String id, String password) throws RoleException{
		Resident r = checkPatientAvailable(id);
		if (r.getType().equalsIgnoreCase("Doctor")) {
			ArrayList<Doctor> d = new ArrayList<Doctor>();
			for (int i=0; i<d.size(); i++) {
				if (r.getUserName().equalsIgnoreCase(d.get(i).getUserName())) {
					d.get(i).setDoctorPassword(password);
				}
			}
		} else if (r.getType().equalsIgnoreCase("Nurse")) {
			ArrayList<Nurse> n = new ArrayList<Nurse>();
			for (int i=0; i<n.size(); i++) {
				if (r.getUserName().equalsIgnoreCase(n.get(i).getUserName())) {
					n.get(i).setNursePassword(password);
				}
			}
		} else {
			throw new RoleException("A patient may not have a password!");
		}
	}
	
	// setting doctor shift
	public void setDoctorShift(String did, int s) throws ShiftException{
		if (s < shiftList.size() && s >= 2) {
			Resident r = new Resident();
			r = checkStaffAvailable(did, "Doctor");
			if (r!=null) {
				for(int i=0; i<doctorList.size(); i++) {
					if (doctorList.get(i).getID().equalsIgnoreCase(r.getID())){
						if (doctorList.get(i).getDoctorShift() == null) {
							throw new ShiftException("Too many shift!");
						}
						doctorList.get(i).setDoctorShift(shiftList.get(s));
					}
				}
			}
		} else {
			System.out.println("No shift or doctor exist!");
		}
	}
	
	// setting nurse shift
	public void setNurseShift(String nid, int s) throws ShiftException{
		if (s < 2 && s >= 0) {
			Resident r = new Resident();
			r = checkStaffAvailable(nid, "Nurse");
			if (r!=null) {
				for(int i=0; i<nurseList.size(); i++) {
					if (nurseList.get(i).getUserName().equalsIgnoreCase(r.getUserName())){
						if (nurseList.get(i).getNurseShift() == null) {
							throw new ShiftException("Too many shift!");
						}
						nurseList.get(i).setNurseShift(shiftList.get(s));
					}
				}
			} else {
				System.out.println("No shift or doctor exist!");
			}
		}
	}
	
	// doctor setting patient prescription
	public void setPatientPrescription(String sid, String pres, int bid) throws RoleException{
		ArrayList<Medicines> patientPrescriptionList=new ArrayList<Medicines>();
		for (int i=0; i<wardList.size();i++) {
			if (!checkDoctorRole(sid)) {
				throw new RoleException("Not a doctor!");
			}
			for (int j=0; j<wardList.get(i).getRoomList().size(); j++) {
				for (int k=0; k<wardList.get(i).getRoomList().get(j).getBeds().size(); k++) {
					if (wardList.get(i).getRoomList().get(j).getBeds().get(k).getBedNo()==bid) {
						Resident r = wardList.get(i).getRoomList().get(j).getBeds().get(k).getResident();
						patientPrescriptionList = r.getPrescription();
						Medicines mAdd = new Medicines(r.getMedicines().get(k).getMedicineName(), pres, r.getTime().get(k).getTime(), r.getDose().get(k).getDose());
						patientPrescriptionList.add(mAdd);
						wardList.get(i).getRoomList().get(j).getBeds().get(k).getResident().setPrescription(patientPrescriptionList);;
					} else {
						System.out.println("The patient is not assign to a bed!");
					}
				}
			}
		}
		logs = sid + "\t" + LocalDateTime.now() + "\tSetting patient prescription of bed ID " + bid;
		logsList.add(logs);
	}
	
	// doctor or nurse setting patient medicine
	public void setPatientMedicine(String pid, String med, String t, int d, String sid) throws RoleException{
		ArrayList<Medicines> patientMedicinesList=new ArrayList<Medicines>();
		for (int i=0; i<wardList.size();i++) {
			if (!checkDoctorRole(sid) || !checkNurseRole(sid)) {
				throw new RoleException("Not a doctor or nurse!");
			}
			for (int j=0; j<wardList.get(i).getRoomList().size(); j++) {
				for (int k=0; k<wardList.get(i).getRoomList().get(j).getBeds().size(); k++) {
					if (wardList.get(i).getRoomList().get(j).getBeds().get(k).getResident().getID().equalsIgnoreCase(pid)) {
						Resident r = checkPatientAvailable(pid);
						patientMedicinesList = r.getMedicines();
						Medicines mAdd = new Medicines(med, r.getPrescription().get(k).getPrescription(), t, d);
						patientMedicinesList.add(mAdd);
						wardList.get(i).getRoomList().get(j).getBeds().get(k).getResident().setMedicines(patientMedicinesList);
					} else {
						System.out.println("The patient is not assign to a bed!");
					}
				}
			}
		}
		logs = sid + "\t" + LocalDateTime.now() + "\tSetting patient medicine of patient ID " + pid;
		logsList.add(logs);
	}
	
	// check if doctor available for id
	public boolean checkDoctorRole(String id) throws RoleException {
		for (int i=0; i<residentList.size(); i++)
			if (residentList.get(i).getID().equalsIgnoreCase(id)) {
				if (residentList.get(i).getType().equalsIgnoreCase("Doctor")) {
					return true;
				}
			}
		return false;
	}
	
	// check if nurse available for id
	public boolean checkNurseRole(String id) throws RoleException{
		for (int i=0; i<residentList.size(); i++)
			if (residentList.get(i).getID().equalsIgnoreCase(id)) {
				if (residentList.get(i).getType().equalsIgnoreCase("Nurse")) {
					return true;
				}
			}
		return false;
	}
	
	// check if resident available
	public Resident checkPatientAvailable(String id) {
		for (int i=0; i<residentList.size(); i++)
			if (residentList.get(i).getID().equalsIgnoreCase(id)) {
				return residentList.get(i);
			}
		return null;
	}
	
	// check if time for roster when login
	public boolean checkRosterAvailable(Shift s) throws RosterException{
		LocalTime t = LocalTime.now();
		LocalTime t1 = LocalTime.parse(s.getStartTime());
		LocalTime t2 = LocalTime.parse(s.getEndTime());
		DateTimeFormatter tFormat = DateTimeFormatter.ISO_LOCAL_TIME;
		LocalTime formattedt = LocalTime.parse(t.format(tFormat));
		if (formattedt.compareTo(t1)>=0 && t2.compareTo(formattedt)>=0)
			return true;
		throw new RosterException("Not shift yet!");
	}
	
	// check if staff type with id available
	public Resident checkStaffAvailable(String id, String type) {
		for (int i=0; i<residentList.size(); i++)
			if (residentList.get(i).getType().equalsIgnoreCase(type)) {
				return residentList.get(i);
			}
		return null;
	}
	
	// add resident to bed
	public void putResidentBed(String type, String nid, Resident r) {
		for (int i=0; i<wardList.size();i++) {
			if (!type.equalsIgnoreCase("Nurse")) {
				break;
			}
			for (int j=0; j<wardList.get(i).getRoomList().size(); j++) {
				for (int k=0; k<wardList.get(i).getRoomList().get(j).getBeds().size(); k++) {
					if(wardList.get(i).getRoomList().get(j).getBeds().get(k).isBedAvailable()) {
						wardList.get(i).getRoomList().get(j).getBeds().get(k).setResident(checkPatientAvailable(r.getID()));
						wardList.get(i).getRoomList().get(j).getBeds().get(k).setBedAvailable(false);
						logs = nid + "\t" + LocalDateTime.now() + "\tPut patient onto bed ID of " + wardList.get(i).getRoomList().get(j).getBeds().get(k).getBedNo();
						logsList.add(logs);
					}
				}
			}
		}
	}
	
	// move resident to other bed
	public void moveResidentBed(String type, String nid, Resident r,int bid) {
		for (int i=0; i<wardList.size();i++) {
			if (!type.equalsIgnoreCase("Nurse")) {
				break;
			}
			if (checkPatientAvailable(r.getID())==null) {
				break;
			}
			for (int j=0; j<wardList.get(i).getRoomList().size(); j++) {
				for (int k=0; k<wardList.get(i).getRoomList().get(j).getBeds().size(); k++) {
					if (wardList.get(i).getRoomList().get(j).getBeds().get(k).getResident().getID().equalsIgnoreCase(r.getID())) {
						wardList.get(i).getRoomList().get(j).getBeds().get(k).setBedAvailable(true);
						wardList.get(i).getRoomList().get(j).getBeds().get(k).setResident(null);
					} else {
						System.out.println("All wards is fully occupied!");
					}
					if (wardList.get(i).getRoomList().get(j).getBeds().get(k).getBedNo()==bid) {
						wardList.get(i).getRoomList().get(j).getBeds().get(k).setBedAvailable(false);
						wardList.get(i).getRoomList().get(j).getBeds().get(k).setResident(r);
						logs = nid + "\t" + LocalDateTime.now() + "\tMove patient from bed ID of " + bid + " to bed ID of " + wardList.get(i).getRoomList().get(j).getBeds().get(k).getBedNo();
						logsList.add(logs);
					}
				}
			}
		}
		
	}
	
	Resident rLogin = new Resident();
	Doctor dLogin = new Doctor();
	Nurse nLogin = new Nurse();
	public void login() {
		System.out.print("Please enter your id:");
		String id = scan.nextLine();
		nLogin.setID(id);
		nLogin.setType("Nurse");
	}
	
	public void mainMenu() {
		System.out.println("Select:");
		System.out.println("2. get staff shift");
		System.out.println("3. set staff shift");
		System.out.println("4. check resident detail on bed");
		System.out.println("5. add prescription");
		System.out.println("6. set medicine");
		System.out.println("7. put resident on bed");
		System.out.println("8. move resident to bed");
		System.out.println("9. print log");
		System.out.println("Any key to exit");
	}
	
	public void run() throws Exception {
		String id;
		String sid;
		int bid;
		String pid;
		String type;
		String nid;
		Resident r = new Resident();
		while(true) {
			mainMenu();
			char ch = scan.nextLine().toUpperCase().charAt(0);
			switch(ch){
				case '2':
					Doctor d = new Doctor();
					Nurse n = new Nurse();
					System.out.print("Please enter id");
					String checkID = scan.nextLine();
					for (int i=0; i<doctorList.size(); i++)
						if (doctorList.get(i).getID().equalsIgnoreCase(checkID)) {
							d = doctorList.get(i);
							System.out.println(d.getDoctorShift());
						}
					for (int i=0; i<nurseList.size(); i++)
						if (nurseList.get(i).getID().equalsIgnoreCase(checkID)) {
							n = nurseList.get(i);
							System.out.println(n.getNurseShift());
						}
					break;
				case '3':
					System.out.println("Select:");
					System.out.println("1. Doctor");
					System.out.println("2. Nurse");
					String i = scan.nextLine();
					System.out.println("Enter id");
					String inputid = scan.nextLine();
					System.out.println("Enter shift (0-3)");
					int inputShift = Integer.parseInt(scan.nextLine());
					if (i.equalsIgnoreCase("1")) {
						setDoctorShift(inputid, inputShift);
					} else {
						setNurseShift(inputid, inputShift);
					}
					break;
				case '4':
					System.out.println("Enter staff id");
					sid = scan.nextLine();
					System.out.println("Enter bed id");
					bid = Integer.parseInt(scan.nextLine());
					showResidentDetialOnBed(sid, bid);
					break;
				case '5':
					System.out.println("Enter staff id");
					sid = scan.nextLine();
					System.out.println("Enter prescription");
					String pres = scan.nextLine();
					System.out.println("Enter bed id");
					bid = Integer.parseInt(scan.nextLine());
					setPatientPrescription(sid, pres, bid);
					break;
				case '6':
					System.out.println("Enter resident id");
					pid = scan.nextLine();
					System.out.println("Enter med");
					String med = scan.nextLine();
					System.out.println("Enter time");
					String t = scan.nextLine();
					System.out.println("Enter dose");
					int dose = Integer.parseInt(scan.nextLine());
					System.out.println("Enter staff id");
					sid = scan.nextLine();
					setPatientMedicine(pid, med, t, dose, sid);
					break;
				case '7':
					System.out.println("Enter resident id");
					id = scan.nextLine();
					for (int j=0;j<residentList.size();j++) {
						if(residentList.get(j).getID().equalsIgnoreCase(id))
							r = residentList.get(j);
					}
					type = "nurse";
					System.out.println("Enter nurse id");
					nid = scan.nextLine();
					putResidentBed(type, nid, r);
					break;
				case '8':
					System.out.println("Enter resident id");
					id = scan.nextLine();
					for (int j=0;j<residentList.size();j++) {
						if(residentList.get(j).getID().equalsIgnoreCase(id))
							r = residentList.get(j);
					}
					type = "nurse";
					System.out.println("Enter nurse id");
					nid = scan.nextLine();
					System.out.println("Enter bed id");
					bid = Integer.parseInt(scan.nextLine());
					moveResidentBed(type, nid, r,bid);
					break;
				case '9':
					for(int k=0; k<logsList.size(); k++)
						System.out.println(logsList.get(k));
					break;
				default:
					System.out.println("See you next time!");
					System.exit(0);
			}
		}
	}
	
	public void initialize() {
		int w = 0;
		int x = 0;
		int y = 0;
		int z = 0;
		Shift s1 = new Shift("8:00:00","16:00:00");
		Shift s2 = new Shift("14:00:00","22:00:00");
		Shift s3 = new Shift("21:00:00","22:00:00");
		Shift s4 = new Shift("15:00:00","16:00:00");
		shiftList.add(s1);
		shiftList.add(s2);
		shiftList.add(s3);
		shiftList.add(s4);
		// hard code, add database later
		for (int i=0; i < 99; i++) {
			Nurse n = new Nurse();
			n.setNurseID(String.valueOf(w));
			n.setNursePassword(null);
			n.setNurseShift(null);
			n.setID(String.valueOf(y));
			n.setFirstName(null);
			n.setLastName(null);
			n.setUserName(null);
			n.setType("Nurse");
			n.setGender(null);
			nurseList.add(n);
			residentList.add(n);
			y++;
			w++;
		}
		
		for (int i=0; i < 99; i++) {
			Doctor d = new Doctor();
			d.setDoctorID(String.valueOf(x));
			d.setDoctorPassword(null);
			d.setDoctorShift(null);
			d.setID(String.valueOf(y));
			d.setFirstName(null);
			d.setLastName(null);
			d.setUserName(null);
			d.setType("Doctor");
			d.setGender(null);
			doctorList.add(d);
			residentList.add(d);
			y++;
			x++;
		}
		
		for (int i=0; i < 999; i++) {
			Resident r = new Resident();
			r.setID(String.valueOf(y));
			r.setFirstName(null);
			r.setLastName(null);
			r.setUserName(null);
			r.setType("Patient");
			r.setGender(null);
			residentList.add(r);
			y++;
		}
		
		
		for(int j = 0; j < 2; j++) {
			Ward ward = new Ward();
			ArrayList<Room> roomList = new ArrayList<Room>();
			for(int i = 0; i < 6; i++) {
				Room room = new Room();
				room.setId(i);
				room.setAvailable(true);
				
				ArrayList<Beds> bedsList = new ArrayList<Beds>();
				if(i == 0) {
					Beds beds = new Beds();
					beds.setBedNo(z);
					beds.setBedAvailable(true);
					bedsList.add(beds);
					z++;
					
				} else if(i == 1) {
					for(int bed = 0; bed < 2; bed++) {
						Beds beds = new Beds();
						beds.setBedNo(z);
						beds.setBedAvailable(true);
						bedsList.add(beds);
						z++;
						
					}
				} else {
					for(int bed = 0; bed < 4; bed++) {
						Beds beds = new Beds();
						beds.setBedNo(z);
						beds.setBedAvailable(false);
						bedsList.add(beds);
						z++;
					}
				}
				room.setBeds(bedsList);
				
				
				roomList.add(room);
			}
			ward.setRoomList(roomList);
			wardList.add(ward);
		}
	}
	
	public static void main(String[] args) throws Exception {
		wardInitialize w = new wardInitialize();
		w.initialize();
		w.login();
		w.run();
	}
}
