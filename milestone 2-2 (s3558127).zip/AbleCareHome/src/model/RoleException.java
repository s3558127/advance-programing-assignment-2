package model;

public class RoleException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RoleException(String errorMessage) {
		super(errorMessage);
	}
}
