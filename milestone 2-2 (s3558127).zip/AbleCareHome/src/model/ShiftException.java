package model;

public class ShiftException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ShiftException(String errorMessage) {
		super(errorMessage);
	}
}
