package model;

public class RosterException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1415116985464090662L;

	public RosterException(String errorMessage) {
		super(errorMessage);
	}
}