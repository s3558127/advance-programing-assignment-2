package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import javafx.fxml.FXML;
import java.io.*;
import java.sql.*;

public class ApplicationMain {
	
	Scanner scan = new Scanner(System.in);
	
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	// connect database
	// .get() substring
	// private int patientid substring +1
	private String logUpdate;
	private int patientid;
	private int doctorid;
	private int nurseid;
	private int shiftid;
	public Manager m;
	private ArrayList<Ward> wardList = new ArrayList<Ward>();
	private ArrayList<String> logList = new ArrayList<String>();
	
	HashMap<String,Bed> bedCheck = new HashMap<String,Bed>();
	HashMap<String,Doctor> doctors = new HashMap<String,Doctor>();
	HashMap<String,Nurse> nurses = new HashMap<String,Nurse>();
	HashMap<String,Patient> patients = new HashMap<String,Patient>();
	HashMap<String,Shift> shifts = new HashMap<String,Shift>();
	
	@FXML
	public void initialize() throws RosterException, StaffException{
		try {
			stmt = con.createStatement();
				
			// initialize shift database
			String sql = "SELECT * FROM shift";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Shift s = new Shift(rs.getString("sid"),rs.getString("starttime"),rs.getString("endtime"));
				shifts.put(rs.getString("sid"), s);
			}
				
			// initialize doctor database
			sql = "SELECT * FROM doctor";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Doctor d = new Doctor(rs.getString("did"),rs.getString("username"));
				d.setPassword(rs.getString("password"));
				d.setShift(shifts.get(rs.getString("sid")));;
				doctors.put(rs.getString("did"), d);
			}
					
			// initialize nurse database
			sql = "SELECT * FROM nurse";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Nurse n = new Nurse(rs.getString("nid"),rs.getString("username"));
				n.setPassword(rs.getString("password"));
				n.setShift(shifts.get(rs.getString("sid")));;
				nurses.put(rs.getString("nid"), n);
			}
				
			// initialize patient database
			sql = "SELECT * FROM patient";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Patient p = new Patient(rs.getString("pid"),rs.getString("firstname"),rs.getString("lastname"),rs.getString("username"),rs.getString("gender").charAt(0));
				patients.put(rs.getString("pid"), p);
			}
			
			sql = "SELECT pid FROM patient \r\n"
					+ "ORDER BY pid DESC  \r\n"
					+ "LIMIT 1;";
			rs = stmt.executeQuery(sql);
			rs.next();
			patientid = Integer.parseInt(rs.getString("pid").replaceAll("[^0-9]", ""))+1;
			
			sql = "SELECT did FROM doctor \r\n"
					+ "ORDER BY did DESC  \r\n"
					+ "LIMIT 1;";
			rs = stmt.executeQuery(sql);
			rs.next();
			doctorid = Integer.parseInt(rs.getString("did").replaceAll("[^0-9]", ""))+1;
			System.out.println(doctorid);
			
			sql = "SELECT nid FROM nurse \r\n"
					+ "ORDER BY nid DESC  \r\n"
					+ "LIMIT 1;";
			rs = stmt.executeQuery(sql);
			rs.next();
			nurseid = Integer.parseInt(rs.getString("nid").replaceAll("[^0-9]", ""))+1;
				
			sql = "SELECT sid FROM shift \r\n"
					+ "ORDER BY sid DESC  \r\n"
					+ "LIMIT 1;";
			rs = stmt.executeQuery(sql);
			rs.next();
			shiftid = Integer.parseInt(rs.getString("sid").replaceAll("[^0-9]", ""))+1;
			System.out.println(shiftid);
			
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
	}
	
	// add manager
	public void setManager(String id) {
		m = new Manager(id);
	}
	
	// add patient
	public boolean addPatient(String loginid, String firstname, String lastname, String username, char gender) throws RosterException, StaffException {
		initialize();
		try {
			if (checkManagerLogin(loginid) || checkDoctorLogin(loginid) || checkNurseLogin(loginid)){
				System.out.println("Success a staff!");
				Patient p = new Patient("p"+patientid,firstname,lastname,username,gender);
				patients.put("p"+patientid, p);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new patient p" + patientid;
				logList.add(logUpdate);
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE username = '" + username  + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next())
					return false;
				else {
					sql = "INSERT INTO patient VALUES('"+ "p"+patientid + "', " +
						"'"+ firstname + "', '" + lastname + "', " +
						"'"+ username + "', '" + gender + "')";
					stmt.executeUpdate(sql);
					return true;
				}
			} else if (checkDoctorLogin(loginid) && checkNurseLogin(loginid) && checkManagerLogin(loginid)){
				System.out.println("Not doctor, nurse or manager!");
					return false;
			} 
			if (!checkRosterAvailable(loginid))
				System.out.println("Not shift yet!");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		return false;
	}
	
	// add doctor
	public boolean addDoctor(String loginid, String username, String password, String sid) throws RosterException, StaffException{
		initialize();
		try {
			if (checkManagerLogin(loginid)){
				stmt = con.createStatement();
				String sql = "SELECT * FROM doctor WHERE username = '" + username  + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next())
					return false;
				else {
					System.out.println("successful added doctor");
					Doctor d = new Doctor("d"+doctorid,username);
					doctors.put("d"+doctorid, d);
					d.setPassword(password);
					d.setShift(shifts.get(sid));
					logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new doctor d" + doctorid;
					logList.add(logUpdate);
					sql = "INSERT INTO doctor VALUES('"+ "d"+doctorid + "', " +
							"'"+ username + "', '" + password + "', " +
							"'"+ sid + "')";
					System.out.println(sql);
					stmt.executeUpdate(sql);
					doctorid++;
					return true;
				}
			} else {
				System.out.println("Not manager!");
				return false;
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		return false;
	}
	
	// add nurse
	public boolean addNurse(String loginid, String username, String password, String sid) throws RosterException, StaffException{
		initialize();
		try {
			if (checkManagerLogin(loginid)){
				stmt = con.createStatement();
				String sql = "SELECT * FROM nurse WHERE username = '" + username  + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next())
					return false;
				else {
					Nurse n = new Nurse("n"+nurseid,username);
					nurses.put("n"+nurseid, n);
					n.setPassword(password);
					n.setShift(shifts.get(sid));
					logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new nurse n" + nurseid;
					logList.add(logUpdate);
					stmt = con.createStatement();
					sql = "INSERT INTO nurse VALUES('"+ "n"+nurseid + "', " +
							"'"+ username + "', '" + password + "', " +
							"'"+ sid + "')";
					System.out.println(sql);
					stmt.executeUpdate(sql);
					nurseid++;
					return true;
				}
			} else {
				System.out.println("Not manager!");
				return false;
			} 
		} catch (SQLException exception) {
	            System.out.println(exception.getMessage());
	            exception.printStackTrace();
			}
			return false;
	}
	
	// set password of staff
	public boolean setPassword(String loginid, String id, String password) throws RosterException, StaffException{
		try {
			stmt = con.createStatement();
				if (id.charAt(0) == 'd') {
					String sql = "UPDATE doctor SET password = '"+ password +"' WHERE did = '" + id + "';";
					stmt.executeUpdate(sql);
					logUpdate = LocalDateTime.now() + "\t" + loginid + " setting password for doctor " + id;
					logList.add(logUpdate);
					return true;
				} else if (id.charAt(0) == 'n') {
					String sql = "UPDATE nurse SET password = '"+ password +"' WHERE nid = '" + id + "';";
					stmt.executeUpdate(sql);
					logUpdate = LocalDateTime.now() + "\t" + loginid + " setting password for nurse " + id;
					logList.add(logUpdate);
					return true;
				} else {
					System.out.println("You are not staff!");
					return false;
				}
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		return false;
	}
	
	// add shift
	public void addShift(String loginid, String starttime, String endtime) throws RosterException, StaffException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT sid FROM shift \r\n"
					+ "ORDER BY sid DESC  \r\n"
					+ "LIMIT 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			shiftid = Integer.parseInt(rs.getString("sid").replaceAll("[^0-9]", ""))+1;
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		try {
			stmt = con.createStatement();
			if (checkManagerLogin(loginid)){
				System.out.println(shiftid);
				Shift s = new Shift("s" + shiftid, starttime, endtime);
				s.setStartTime(starttime);
				s.setEndTime(endtime);
				shifts.put("s" + shiftid, s);
				String sql = "INSERT INTO shift VALUES('"+ "s"+shiftid + "', " +
						"'"+ starttime + "', '" + endtime + "')";
				System.out.println(sql);
				stmt.executeUpdate(sql);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new shift choice " + starttime + " to "+ endtime;
				logList.add(logUpdate);
				shiftid++;
			} else {
				throw new StaffException("Not manager!");
			}
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
	}
	
	// set shift
	public boolean setShift(String loginid, String id, String shiftid) throws RosterException, StaffException{
		try {
			if (checkManagerLogin(loginid)){
				if (id.charAt(0) == 'd') {
					stmt = con.createStatement();
					String sql = "SELECT * FROM shift where sid = '" + shiftid + "';";
					ResultSet rs = stmt.executeQuery(sql);
					if (rs.next()) {
						logUpdate = LocalDateTime.now() + "\t" + loginid + " setting shift " + rs.getString("starttime") + " to "+ rs.getString("endtime") + " for doctor " + id;
						logList.add(logUpdate);
						System.out.println("Success doctor");
						sql = "UPDATE doctor SET sid = '"+ shiftid +"' WHERE did = '" + id + "';";
						stmt.executeUpdate(sql);
						return true;
					} else
						return false;
				} else if (id.charAt(0) == 'n') {
					stmt = con.createStatement();
					String sql = "SELECT * FROM shift where sid = '" + shiftid + "';";
					ResultSet rs = stmt.executeQuery(sql);
					if (rs.next()) {
						logUpdate = LocalDateTime.now() + "\t" + loginid + " setting shift " + rs.getString("starttime") + " to "+ rs.getString("endtime") + " for nurse " + id;
						logList.add(logUpdate);
						System.out.println("Success nurse");
						sql = "UPDATE nurse SET sid = '"+ shiftid +"' WHERE nid = '" + id + "';";
						stmt.executeUpdate(sql);
						return true;
					} else
						return false;
				} else {
					System.out.println("Not manager!");
					return false;
				}
			}
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		return false;
	}
	
	// move patient on bed
	public boolean movePatientOnBed(String loginid, String id, String bedid)  throws RosterException, StaffException{
		try {
			String initialBed;
			stmt = con.createStatement();
			String sql = "SELECT * FROM bed where pid = '" + id + "';";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()) {
				initialBed = rs.getString("bid");
				
				sql = "SELECT * FROM bed where bid = '" + bedid + "';";
				rs = stmt.executeQuery(sql);
				if(rs.next()) {
					if (rs.getString("available").equalsIgnoreCase("1")) {
						sql = "UPDATE bed SET pid = null, available = 1 WHERE bid = '" + initialBed + "';";
						stmt.executeUpdate(sql);
						sql = "UPDATE bed SET pid = '"+ id +"', available = 0 WHERE bid = '" + bedid + "';";
						stmt.executeUpdate(sql);
						logUpdate = LocalDateTime.now() + "\t" + loginid + " move patient " + id + " to bed" + bedid;
						logList.add(logUpdate);
						return true;
					}
				} else
					return false;
			} else {
				System.out.println("Patient not on bed!");
			}
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		return false;
//		boolean initialBed = false;
//		Iterator<String> bedIterator = bedCheck.keySet().iterator();
//		if (checkDoctorLogin(loginid) || checkNurseLogin(loginid) || checkManagerLogin(loginid)){
//			if (patients.containsKey(id) && bedCheck.get(bedid).isBedAvailable()) {
//				while (bedIterator.hasNext()) {
//					String bedIdTemp = bedIterator.next();
//					if (bedCheck.get(bedIdTemp).getPatient()!=null)
//						if(bedCheck.get(bedIdTemp).getPatient().getId().equalsIgnoreCase(id)) {
//							bedCheck.get(bedIdTemp).setPatient(null);
//							bedCheck.get(bedIdTemp).setBedAvailable(true);
//							initialBed = true;
//							putPatientOnBed(loginid,id,bedid);
//						}
//				}
//				if (!initialBed)
//					System.out.println("Patient not on any bed!");
//			} else {
//				System.out.println("Patient or Bed is not available!");
//			}
//		} else
//			System.out.println("Not doctor, nurse or manager!");
//		if (!checkRosterAvailable(loginid))
//			System.out.println("Not shift yet!");
	}
	
	public boolean checkOutPatient(String loginid, String id){
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM bed where pid = '" + id + "';";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()) {
				logUpdate = LocalDateTime.now() + "\t" + loginid + " checkout patient " + id + " to bed" + rs.getString("bid");
				logList.add(logUpdate);
				sql = "UPDATE bed SET pid = null, available = 1 WHERE bid = '" + rs.getString("bid") + "';";
				stmt.executeUpdate(sql);
				return true;
			} else
				return false;
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		return false;
	}
	
	// put patient on bed
	public boolean putPatientOnBed(String loginid, String id, String bedid) throws RosterException, StaffException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM bed where bid = '" + bedid + "';";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()) {
				if(rs.getString("available").equalsIgnoreCase("1")) {
					sql = "UPDATE bed SET pid = '"+ id +"', available = 0 WHERE bid = '" + bedid + "';";
					stmt.executeUpdate(sql);
					logUpdate = LocalDateTime.now() + "\t" + loginid + " put patient " + id + " to bed" + bedid;
					logList.add(logUpdate);
					return true;
				}
				return false;
			}
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		return false;
	}
		// Iterator<String> bedIterator = bedCheck.keySet().iterator();
		//boolean patientOnBed = false;
		 //if (checkDoctorLogin(loginid) || checkNurseLogin(loginid) || checkManagerLogin(loginid)){
		//	while (bedIterator.hasNext()) {
			//	String idTemp = bedIterator.next();
			//	if (bedCheck.get(idTemp).getPatient()!=null)
			//		if (bedCheck.get(idTemp).getPatient().getId().equalsIgnoreCase(id)) {
			//			System.out.println("Patient on bed " + bedCheck.get(idTemp).getBedid() + " already!");
			//			patientOnBed = true;
		//			}
		//	}
			//if (bedCheck.get(bedid).isBedAvailable() && patients.containsKey(id) && !patientOnBed) {
		//		bedCheck.get(bedid).setPatient(patients.get(id));
			//	logUpdate = LocalDateTime.now() + "\t" + loginid + " move patient " + id + " to bed" + bedid;
			//	logList.add(logUpdate);
			//}
		//	if (!patients.containsKey(id)){
		//		System.out.println("Patient ID is not available!");
		//	}
		//} else
		//	System.out.println("Not doctor, nurse or manager!");
	//	if (!checkRosterAvailable(loginid))
		//	System.out.println("Not shift yet!");
	
	
	// check patient on bed
	public boolean getBedPatientDetails(String loginid, String id) throws StaffException, RosterException{
		String targetPatient;
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM bed WHERE bid = '" + id + "'";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()) {
				if(rs.getString("pid")!=null) {
					targetPatient = rs.getString("pid");
					sql = "UPDATE showpatient SET patientid = '"+ targetPatient +"' WHERE id = '" + 1 + "';";
					stmt.executeUpdate(sql);
					if (checkManagerLogin(loginid) || checkDoctorLogin(loginid) || checkNurseLogin(loginid)){
						logUpdate = LocalDateTime.now() + "\t" + loginid + " checking patient " + id + " details";
						logList.add(logUpdate);
						return true;
					} else {
						System.out.println("Not doctor, nurse or manager!");
						return false;
					}
				} else {
					System.out.println("No patient on the bed!");
					return false;
				}
			}
		} catch (SQLException exception) {
			System.out.println(exception.getMessage());
			exception.printStackTrace();
		}
		return false;
	}
	
	// setting patient medicine
	public void setMedicine(String loginid, String id, String med, String time, int dose) throws RosterException, StaffException{
		if (checkDoctorLogin(loginid)) {
			System.out.println("Sucess!");
			if (!checkRosterAvailable(loginid))
				throw new RosterException("Not shift yet!");
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE pid = '" + id + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					sql = "INSERT INTO medicine (pid,med,time,dose) VALUES('"+ id + "', " +
							"'"+ med + "', '" + time + "', " +
							"'"+ dose + "')";
					stmt.executeUpdate(sql);
					logUpdate = LocalDateTime.now() + "\t" + loginid + " setting medicine for patient " + id;
					logList.add(logUpdate);
				}
			}catch (SQLException exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
		} else {
			throw new StaffException("Not doctor!");
		}
	}
	
	
	// setting patient prescription
	public void setPrescription(String loginid, String id, String pres) throws RosterException, StaffException{
		if (checkDoctorLogin(loginid)) {
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE pid = '" + id + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					sql = "INSERT INTO prescription (pid,prescription) VALUES ('"+ id + "', " +
							"'"+ pres + "')";
					stmt.executeUpdate(sql);
					logUpdate = LocalDateTime.now() + "\t" + loginid + " setting prescription for patient " + id;
					logList.add(logUpdate);
				}
			} catch (SQLException exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
		} else
			throw new StaffException("Not doctor!");
		if (!checkRosterAvailable(loginid))
			throw new RosterException("Not shift yet!");

	}
	
	// display available bed
	public void displayAllBed(){
		Iterator<String> bedIterator = bedCheck.keySet().iterator();
		Iterator<Bed> valueIterator = bedCheck.values().iterator();
		System.out.println("Bed ID \t" + "Available \t" + "Patient ID");
		while (bedIterator.hasNext()) {
			String idTemp = valueIterator.next().getBedid();
			if (bedCheck.get(idTemp).getPatient()!=null)
				System.out.println(bedIterator.next()+ "\t" + bedCheck.get(idTemp).isBedAvailable() + "\t\t" + bedCheck.get(idTemp).getPatient().getId());
			else
				System.out.println(bedIterator.next()+ "\t" + bedCheck.get(idTemp).isBedAvailable() + "\t\t" + "Available");
		}
	}
	
	// check doctor login permission
	public boolean checkDoctorLogin(String loginid) throws StaffException, RosterException{
		System.out.println(checkRosterAvailable(loginid));
		try{
			stmt = con.createStatement();
			String sql = "SELECT * FROM doctor where did = '" + loginid + "';";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next()&& checkRosterAvailable(loginid))
				return true;
			else {
				throw new RosterException("Not shift yet!");
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		return false;
	}
	
	// check nurse login permission
	public boolean checkNurseLogin(String loginid) throws StaffException, RosterException{
		System.out.println(checkRosterAvailable(loginid));
		try{
			stmt = con.createStatement();
			String sql = "SELECT * FROM nurse where nid = '" + loginid + "';";
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next() && checkRosterAvailable(loginid))
				return true;
			else 
				return false;
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		return false;
			
	}
	
	// check manager login permission
	public boolean checkManagerLogin(String loginid) throws StaffException{
		if(loginid.equalsIgnoreCase("admin"))
			return true;
		else {
			return false;
		}
	}
	
	// check shift
	public boolean checkRosterAvailable(String loginid) throws RosterException, StaffException{
		LocalTime t = LocalTime.now();
		DateTimeFormatter timeFormat = DateTimeFormatter.ISO_LOCAL_TIME;
		LocalTime formattedt = LocalTime.parse(t.format(timeFormat));
		LocalTime t1;
		LocalTime t2;
		String sid = null;
		if (loginid.equalsIgnoreCase("admin"))
			return true;
		else {
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM doctor where did = '" + loginid + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if (rs.next()) {
					sid = rs.getString("sid");
				}
				sql = "SELECT * FROM nurse where nid = '" + loginid + "';";
				rs = stmt.executeQuery(sql);
				if (rs.next()) {
					sid = rs.getString("sid");
				}
			} catch (SQLException exception) {
	            System.out.println(exception.getMessage());
	            exception.printStackTrace();
			}
			
			System.out.println(sid);
			
			if (sid!=null) {
				try {
					String sql = "SELECT * FROM shift WHERE sid = '" + sid + "';";
					ResultSet rs = stmt.executeQuery(sql);
					if (rs.next()) {
						System.out.println(rs.getString("starttime"));
						t1 = LocalTime.parse(rs.getString("starttime"));
						t2 = LocalTime.parse(rs.getString("endtime"));
						if (formattedt.compareTo(t1)>=0 && t2.compareTo(formattedt)>=0)
							return true;
					} else {
						return false;
					}
				} catch (SQLException exception) {
					System.out.println(exception.getMessage());
					exception.printStackTrace();
				}
			}
		}
		//else if (loginid.charAt(0) == 'd' && doctors.get(loginid)!=null) {
		//	if (doctors.get(loginid).getShift() != null) {
		//		t1 = LocalTime.parse(doctors.get(loginid).getShift().getStartTime());
		//		t2 = LocalTime.parse(doctors.get(loginid).getShift().getEndTime());
		//		if (formattedt.compareTo(t1)>=0 && t2.compareTo(formattedt)>=0)
		//			return true;
//			} else
//				return false;
//		} else if (loginid.charAt(0) == 'n' && nurses.get(loginid).getShift()!= null) {
//			if (nurses.get(loginid).getShift() != null) {
//				t1 = LocalTime.parse(nurses.get(loginid).getShift().getStartTime());
//				t2 = LocalTime.parse(nurses.get(loginid).getShift().getEndTime());
//				if (formattedt.compareTo(t1)>=0 && t2.compareTo(formattedt)>=0)
//					return true;
//			} else
//				return false;
//		}
		return false;
	}
	
	// print log
	public void printLog() {
		Iterator<String> logIterator = logList.iterator();
		while (logIterator.hasNext()) {
			System.out.println(logIterator.next());
		}
	}
	
	// initialize everything
	public void initializeBackEnd() throws RosterException, StaffException{
		
		// initialize first manager
		setManager("admin");
		
		// ward, room, bed initialize
		int wardid = 1;
		for(int j = 0; j < 2; j++) {
			Ward ward = new Ward("w" + wardid);
			int roomid = 1;
			ArrayList<Room> roomList = new ArrayList<Room>();
			for(int i = 0; i < 6; i++) {
				Room room = new Room("w" + wardid+"r"+roomid);
				
				ArrayList<Bed> bedList = new ArrayList<Bed>();
				int bedid = 1;
				if(i == 0) {
					Bed beds = new Bed("w" + wardid+"r"+roomid+"b" + bedid);
					bedList.add(beds);
					bedCheck.put("w" + wardid+"r"+roomid+"b" + bedid,beds);
					bedid++;
				} else if(i == 1) {
					for(int bed = 0; bed < 2; bed++) {
						Bed beds = new Bed("w" + wardid+"r"+roomid+"b" + bedid);
						bedList.add(beds);
						bedCheck.put("w" + wardid+"r"+roomid+"b" + bedid,beds);
						bedid++;
					}
				} else {
					for(int bed = 0; bed < 4; bed++) {
						Bed beds = new Bed("w" + wardid+"r"+roomid+"b" + bedid);
						bedList.add(beds);
						bedCheck.put("w" + wardid+"r"+roomid+"b" + bedid,beds);
						bedid++;
					}
				}
				room.setBed(bedList);
				roomList.add(room);
				roomid++;
			}
			wardid++;
			ward.setRoomList(roomList);
			wardList.add(ward);
		}
		
		
	}
	
	public void mainMenu() {
		System.out.println("Select:");
		System.out.println("1. set staff shift");
		System.out.println("2. get staff shift");
		System.out.println("3. put resident on bed");
		System.out.println("4. check resident on bed");
		System.out.println("5. move resident on bed");
		System.out.println("6. set medicine");
		System.out.println("7. add prescription");
		System.out.println("8. print log");
		System.out.println("9. display all bed");
		System.out.println("10. display medicine");
		System.out.println("11. display prescription");
		System.out.println("Any key to exit");
	}
	
	public void run() throws RosterException, StaffException{
		String input;
		Patient p = patients.get("p1");
		while (true) {
			mainMenu();
			String ch = scan.nextLine().toUpperCase();
			switch(ch) {
				case "1":
					setShift("admin","d1","s2");
					setShift("admin","d2","s2");
					break;
				case "2":
					input = scan.nextLine();
					if(input.charAt(0) == 'd')
						doctors.get(input).displayShift();
					else if (input.charAt(0) == 'd')
						nurses.get(input).displayShift();
					else
						System.out.println("No shift available!");
					break;
				case "3":
					putPatientOnBed("admin", "p1", "w1r6b4");
					break;
				case "4":
					getBedPatientDetails("admin","w1r6b4");
					getBedPatientDetails("p1","w2r1b1");
					break;
				case "5":
					movePatientOnBed("admin","p1","w2r1b1");
					break;
				case "6":
					setMedicine("d2","p1","med1","00:00:00",2);
					setMedicine("d2","p1","med2","02:00:00",2);
					break;
				case "7":
					setPrescription("d1","p1","try pres 1");
					setPrescription("d2","p1","try pres 2");
					break;
				case "8":
					printLog();
					break;
				case "9":
					displayAllBed();
					break;
				case "10":
					p.displayMedicine();
					break;
				case "11":
					p.displayPrescription();
					break;
				default:
					System.out.println("See you next time!");
					System.exit(0);
			}
		}
	}
	
	public static void main(String[] args) throws RosterException, StaffException {
		ApplicationMain start = new ApplicationMain();
		start.initializeBackEnd();
		start.run();
	}
}
