package controller;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

public class ModifyShiftPage {

	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML 
	private ChoiceBox<String> shiftBox;
	@FXML
	private Button addShiftButton;
	@FXML
	private Button setShiftButton;
	@FXML
	private TextField starttime;
	@FXML
	private TextField endtime;
	@FXML
	private TextField username;
	@FXML
	private Label invalid;
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	ArrayList<String> timeList = new ArrayList<String>();
	ObservableList<String> shiftList;
	
	@FXML 
	private ChoiceBox<String> idBox;
	ArrayList<String> idList = new ArrayList<String>();
	ObservableList<String> idsList;
	private String targetID = null;
	
	String usernameInput;
	String shift;
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
    	try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM doctor;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String did = rs.getString("did");
				idList.add(did);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
    	try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM nurse;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String nid = rs.getString("nid");
				idList.add(nid);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		idsList = FXCollections.observableArrayList(idList);
		idBox.setItems(idsList);
		idBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!idBox.getValue().isEmpty())
                targetID = idBox.getValue();
        });
    	
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM shift;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String sid = rs.getString("sid");
				String starttime = rs.getString("starttime");
				String endtime = rs.getString("endtime");
				String time = sid + ": " + starttime + " to " + endtime;
				timeList.add(time);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		shiftList = FXCollections.observableArrayList(timeList);
		shiftBox.setItems(shiftList);
		shiftBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!shiftBox.getValue().isEmpty())
                shift = shiftBox.getValue();
        });
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		m.changeScene("/fxml/MenuPage.fxml");
	}
	
	@FXML
	public void addShift(ActionEvent event) throws IOException, RosterException, StaffException{
		if (starttime.getText().isEmpty() || endtime.getText().isEmpty())
			invalid.setText("Please fill in the blank!");
		else {
			try {
				DateTimeFormatter strictTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss").withResolverStyle(ResolverStyle.STRICT);
				LocalTime.parse(starttime.getText(), strictTimeFormatter);
				LocalTime.parse(endtime.getText(), strictTimeFormatter);
				start.addShift("admin", starttime.getText(), endtime.getText());
				m.changeScene("/fxml/MenuPage.fxml");
			} catch (DateTimeParseException | NullPointerException e) {
				invalid.setText("Date format is 00:00:00!");
				starttime.setText("");
				endtime.setText("");
		    }
		}
	}
	
	@FXML
	public void setShift(ActionEvent event) throws IOException, RosterException, StaffException{
		String shiftid = null;
		for (int i=0; i<shiftList.size();i++)
			if(shiftList.get(i).equalsIgnoreCase(shiftBox.getValue()))
				shiftid = "s" + Integer.toString(i);
		if (targetID == null)
			invalid.setText("Please select id!");
		else {
			System.out.println(shiftid);
			if(start.setShift(id, targetID, shiftid)) {
				System.out.println("Successfull set shift!");
				invalid.setText("Successfull set shift!");
			}else {
				System.out.println("ID doesnt exist!");
				invalid.setText("ID doesnt exist!");
			}
		}
	}
}
