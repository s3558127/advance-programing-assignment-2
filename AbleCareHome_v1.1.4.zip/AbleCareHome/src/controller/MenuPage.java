package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class MenuPage {
	
	ApplicationMain start = new ApplicationMain();
	@FXML
	private Label invalid;
	@FXML
	private Button logOutButton;
	@FXML
	private Button addPatientButton;
	@FXML
	private Button addStaffButton;
	@FXML
	private Button modifyShiftButton;
	@FXML
	private Button changePasswordButton;
	@FXML
	private Button goToBedViewButton;
	@FXML
	Main m = new Main();
	
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
	@FXML
	public void initialize() throws IOException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
	        System.out.println(exception.getMessage());
	         exception.printStackTrace();
	    }
	 }
	
	@FXML
	public void userLogOut(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/MainPage.fxml");
	}
	
	@FXML
	public void addStaff(ActionEvent event) throws IOException{
		if (id.equalsIgnoreCase("admin"))
			m.changeScene("/fxml/AddStaffPage.fxml");
		else
			invalid.setText("Only admin!");
	}
	
	@FXML
	public void addPatient(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/AddPatientPage.fxml");
	}
	
	@FXML
	public void modifyShift(ActionEvent event) throws IOException{
		if (id.equalsIgnoreCase("admin"))
			m.changeScene("/fxml/ModifyShiftPage.fxml");
		else
			invalid.setText("Only admin!");
	}
	
	@FXML
	public void changePassword(ActionEvent event) throws IOException{
		m.changeScene("/fxml/ChangePasswordPage.fxml");
	}
	
	@FXML
	public void goToBedView(ActionEvent event) throws IOException{
		m.changeScene("/fxml/BedViewPage.fxml");
	}
	
}
