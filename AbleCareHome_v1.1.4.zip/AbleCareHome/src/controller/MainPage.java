package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class MainPage{
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML 
	private ChoiceBox<String> accountTypeBox;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private Label invalidDetails;
	@FXML
	private Button loginButton;
	@FXML
	private Button exitButton;
	
	@FXML
	Main m = new Main();
	
	ObservableList<String> accountTypeList = FXCollections.observableArrayList("Doctor", "Nurse");
	
	Parent root = null;
	Scene scene = null;
	Stage stage = null;
	
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
    
    String type;
    String loginid;
    
    // initialize
    @FXML
    public void initialize() {
        accountTypeBox.setItems(accountTypeList);
        accountTypeBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!accountTypeBox.getValue().isEmpty())
                type = accountTypeBox.getValue();    	
        });
    }
    
	// collect input data
	private String checkLogin() throws IOException{
		try {
			stmt = con.createStatement();
			if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
				return "admin";
			}else if(username.getText().isEmpty() || password.getText().isEmpty() || accountTypeBox.getValue() == null) {
				invalidDetails.setText("Please enter username, password or type!");
			} else if (type.equalsIgnoreCase("Doctor")){
				String sql = "SELECT * FROM doctor where username = '"+ username.getText() +"' and password = '"+ password.getText() +"';";
				ResultSet rs = stmt.executeQuery(sql);
				if (rs.next())
					return rs.getString("did");
				else {
					invalidDetails.setText("Wrong username or password!");
					username.setText("");
					password.setText("");
				}
			} else if (type.equalsIgnoreCase("Nurse")){
				String sql = "SELECT * FROM nurse where username = '"+ username.getText() +"' and password = '"+ password.getText() +"';";
				ResultSet rs = stmt.executeQuery(sql);
				if (rs.next())
					return rs.getString("nid");
				else {
					invalidDetails.setText("Wrong username or password!");
					username.setText("");
					password.setText("");
				}
			} else if (type.equalsIgnoreCase("Patient")){
				String sql = "SELECT * FROM patient where username = '"+ username.getText() +"';";
				ResultSet rs = stmt.executeQuery(sql);
				if (rs.next())
					return rs.getString("pid");
				else {
					invalidDetails.setText("Wrong username or password!");
					username.setText("");
					password.setText("");
				}
			} else 
				invalidDetails.setText("Please select type!");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		return null;
	}
	
	// login button
	@FXML
	public void userLogin(ActionEvent event) throws IOException, RosterException, StaffException{
		if(start.checkRosterAvailable(checkLogin())) {
			if(checkLogin()!=null) {
				}
				try {
					String sql = "UPDATE user SET loginid = '"+ checkLogin() +"' WHERE id = '" + 1 + "';";
					stmt.executeUpdate(sql);
				} catch (SQLException exception) {
	        	   System.out.println(exception.getMessage());
	        	   exception.printStackTrace();
				}	
				m.changeScene("/fxml/MenuPage.fxml");
			}
		else
			invalidDetails.setText("Not shift yet!");
	}
	
	@FXML
	public void userExit(ActionEvent event) throws IOException{
		start.printLog();
		stage = (Stage) exitButton.getScene().getWindow();
	    stage.close();
	}
}
