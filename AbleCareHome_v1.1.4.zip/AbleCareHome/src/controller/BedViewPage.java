package controller;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import javafx.scene.paint.Color; 


import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class BedViewPage {
	
	@FXML 
	private ChoiceBox<String> patientBox;
	ArrayList<String> patientList = new ArrayList<String>();
	ObservableList<String> patientsList;
	
	@FXML 
	private ChoiceBox<String> bedBox;
	ArrayList<String> bedList = new ArrayList<String>();
	ObservableList<String> bedsList;
	
	private HashMap<String, Button> buttonList = new HashMap<String, Button>();
	String targetPatient=null;
	// ward 1 room 1
	@FXML
	private Button w1r1b1;
	@FXML
	public void w1r1b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r1b1.getText();
		initialize();
	}
	
	// ward 1 room 2
	@FXML
	private Button w1r2b1;
	@FXML
	public void w1r2b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r2b1.getText();
		initialize();
	}
	@FXML
	private Button w1r2b2;
	@FXML
	public void w1r2b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r2b2.getText();
		initialize();
	}
	
	// ward 1 room 3 to 6
	@FXML
	private Button w1r3b1;
	@FXML
	public void w1r3b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r3b1.getText();
		initialize();
	}
	@FXML
	private Button w1r3b2;
	@FXML
	public void w1r3b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r3b2.getText();
		initialize();
	}
	@FXML
	private Button w1r3b3;
	@FXML
	public void w1r3b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r3b3.getText();
		initialize();
	}
	@FXML
	private Button w1r3b4;
	@FXML
	public void w1r3b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r2b2.getText();
		initialize();
	}
	
	@FXML
	private Button w1r4b1;
	@FXML
	public void w1r4b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r4b1.getText();
		initialize();
	}
	@FXML
	private Button w1r4b2;
	@FXML
	public void w1r4b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r4b2.getText();
		initialize();
	}
	@FXML
	private Button w1r4b3;
	@FXML
	public void w1r4b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r4b3.getText();
		initialize();
	}
	@FXML
	private Button w1r4b4;
	@FXML
	public void w1r4b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r4b4.getText();
		initialize();
	}
	
	@FXML
	private Button w1r5b1;
	@FXML
	public void w1r5b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r5b1.getText();
		initialize();
	}
	@FXML
	private Button w1r5b2;
	@FXML
	public void w1r5b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r5b2.getText();
		initialize();
	}
	@FXML
	private Button w1r5b3;
	@FXML
	public void w1r5b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r5b3.getText();
		initialize();
	}
	@FXML
	private Button w1r5b4;
	@FXML
	public void w1r5b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r5b4.getText();
		initialize();
	}
	
	@FXML
	private Button w1r6b1;
	@FXML
	public void w1r6b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r6b1.getText();
		initialize();
	}
	@FXML
	private Button w1r6b2;
	@FXML
	public void w1r6b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r6b2.getText();
		initialize();
	}
	@FXML
	private Button w1r6b3;
	@FXML
	public void w1r6b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r6b3.getText();
		initialize();
	}
	@FXML
	private Button w1r6b4;
	@FXML
	public void w1r6b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w1r6b4.getText();
		initialize();
	}
	
	// ward 2 room 1
	@FXML
	private Button w2r1b1;
	@FXML
	public void w2r1b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r1b1.getText();
		initialize();
	}
	
	// ward 2 room 2
	@FXML
	private Button w2r2b1;
	public void w2r2b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r2b1.getText();
		initialize();
	}
	@FXML
	private Button w2r2b2;
	public void w2r2b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r2b2.getText();
		initialize();
	}
	
	// ward 2 room 3 to 6
	@FXML
	private Button w2r3b1;
	public void w2r3b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r3b1.getText();
		initialize();
	}
	@FXML
	private Button w2r3b2;
	public void w2r3b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r3b2.getText();
		initialize();
	}
	@FXML
	private Button w2r3b3;
	public void w2r3b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r3b3.getText();
		initialize();
	}
	@FXML
	private Button w2r3b4;
	public void w2r3b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r3b4.getText();
		initialize();
	}
	
	@FXML
	private Button w2r4b1;
	public void w2r4b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r4b1.getText();
		initialize();
	}
	@FXML
	private Button w2r4b2;
	public void w2r4b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r4b2.getText();
		initialize();
	}
	@FXML
	private Button w2r4b3;
	public void w2r4b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r4b3.getText();
		initialize();
	}
	@FXML
	private Button w2r4b4;
	public void w2r4b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r4b4.getText();
		initialize();
	}
	
	@FXML
	private Button w2r5b1;
	public void w2r5b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r5b1.getText();
		initialize();
	}
	@FXML
	private Button w2r5b2;
	public void w2r5b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r5b2.getText();
		initialize();
	}
	@FXML
	private Button w2r5b3;
	public void w2r5b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r5b3.getText();
		initialize();
	}
	@FXML
	private Button w2r5b4;
	public void w2r5b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r5b4.getText();
		initialize();
	}
	
	@FXML
	private Button w2r6b1;
	public void w2r6b1(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r6b1.getText();
		initialize();
	}
	@FXML
	private Button w2r6b2;
	public void w2r6b2(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r6b2.getText();
		initialize();
	}
	@FXML
	private Button w2r6b3;
	public void w2r6b3(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r6b3.getText();
		initialize();
	}
	@FXML
	private Button w2r6b4;
	public void w2r6b4(ActionEvent event) throws IOException, RosterException, StaffException{
		targetPatient = w2r6b4.getText();
		initialize();
	}
	
	
	@FXML
	private String patientid = null;
	@FXML
	private String bedid = null;
	@FXML
	private Button putButton;
	@FXML
	private Button checkOutButton;
	@FXML
	private Button moveButton;
	@FXML
	private Label invalid;
	@FXML
	private Button back;
	@FXML
	private Button patientConfigurationButton;
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML
	Main m = new Main();
	
	String bed;
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException, RosterException, StaffException{
    	
    	buttonList.clear();
    	buttonList.put("w1r1b1", w1r1b1);
    	buttonList.put("w1r2b1", w1r2b1);
    	buttonList.put("w1r2b2", w1r2b2);
    	buttonList.put("w1r3b1", w1r3b1);
    	buttonList.put("w1r3b2", w1r3b2);
    	buttonList.put("w1r3b3", w1r3b3);
    	buttonList.put("w1r3b4", w1r3b4);
    	buttonList.put("w1r4b1", w1r4b1);
    	buttonList.put("w1r4b2", w1r4b2);
    	buttonList.put("w1r4b3", w1r4b3);
    	buttonList.put("w1r4b4", w1r4b4);
    	buttonList.put("w1r5b1", w1r5b1);
    	buttonList.put("w1r5b2", w1r5b2);
    	buttonList.put("w1r5b3", w1r5b3);
    	buttonList.put("w1r5b4", w1r5b4);
    	buttonList.put("w1r6b1", w1r6b1);
    	buttonList.put("w1r6b2", w1r6b2);
    	buttonList.put("w1r6b3", w1r6b3);
    	buttonList.put("w1r6b4", w1r6b4);
    	
    	buttonList.put("w2r1b1", w2r1b1);
    	buttonList.put("w2r2b1", w2r2b1);
    	buttonList.put("w2r2b2", w2r2b2);
    	buttonList.put("w2r3b1", w2r3b1);
    	buttonList.put("w2r3b2", w2r3b2);
    	buttonList.put("w2r3b3", w2r3b3);
    	buttonList.put("w2r3b4", w2r3b4);
    	buttonList.put("w2r4b1", w2r4b1);
    	buttonList.put("w2r4b2", w2r4b2);
    	buttonList.put("w2r4b3", w2r4b3);
    	buttonList.put("w2r4b4", w2r4b4);
    	buttonList.put("w2r5b1", w2r5b1);
    	buttonList.put("w2r5b2", w2r5b2);
    	buttonList.put("w2r5b3", w2r5b3);
    	buttonList.put("w2r5b4", w2r5b4);
    	buttonList.put("w2r6b1", w2r6b1);
    	buttonList.put("w2r6b2", w2r6b2);
    	buttonList.put("w2r6b3", w2r6b3);
    	buttonList.put("w2r6b4", w2r6b4);
    	
    	if(targetPatient!=null) {
    		if(start.getBedPatientDetails(id, targetPatient))
    			m.changeScene("/fxml/ShowBedPatient.fxml");
    		else
    			invalid.setText("No patient on bed!");
    	}
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM bed ;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				if(rs.getString("pid")!=null) {
					Statement stmt2 = con.createStatement();
					String sql2 = "SELECT * FROM patient WHERE pid = '" + rs.getString("pid") + "';";
					ResultSet rs2 = stmt2.executeQuery(sql2);
					if (rs2.next()) {
						if(rs2.getString("gender").charAt(0) == 'M')
							buttonList.get(rs.getString("bid")).setStyle("-fx-background-color: #00FFFF; ");
						else
							buttonList.get(rs.getString("bid")).setStyle("-fx-background-color: #FF1493; ");
					}
				} else
					buttonList.get(rs.getString("bid")).setStyle("-fx-background-color: #F0FFFF; ");
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		patientList.clear();
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM patient;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String pid = rs.getString("pid");
				patientList.add(pid);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		patientsList = FXCollections.observableArrayList(patientList);
		patientBox.setItems(patientsList);
		patientBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!patientBox.getValue().isEmpty())
                patientid = patientBox.getValue();
        });
		
		bedList.clear();
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM bed;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String bid = rs.getString("bid");
				bedList.add(bid);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		bedsList = FXCollections.observableArrayList(bedList);
		bedBox.setItems(bedsList);
		bedBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!bedBox.getValue().isEmpty())
                bedid = bedBox.getValue();
        });
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/MenuPage.fxml");
	}
	
	@FXML
	public void patientConfiguration(ActionEvent event) throws IOException{
		if (id.charAt(0) == 'd')
			m.changeScene("/fxml/PatientConfigurationPage.fxml");
		else
			invalid.setText("Only doctor have the permission!");
	}
	
	public void put(ActionEvent event) throws IOException, RosterException, StaffException{
		initialize();
		if(patientid == null)
			invalid.setText("Please select patient id!");
		else if (bedid == null)
			invalid.setText("Please select bed id!");
		else
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE pid = '" + patientid + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					stmt = con.createStatement();
					sql = "SELECT * FROM bed WHERE pid = '" + patientid + "';";
					ResultSet rs2 = stmt.executeQuery(sql);
					if(rs2.next())
						invalid.setText("Patient is on bed " + rs2.getString("bid"));
					else
						if(start.putPatientOnBed(id, patientid, bedid))
							invalid.setText(patientid + " added to bed " + bedid);
						else
							invalid.setText("Someone on the bed!");
				}
				else
					invalid.setText("Invalid patient id");
			} catch (SQLException exception) {
	            System.out.println(exception.getMessage());
	            exception.printStackTrace();
	        }
		initialize();
	}
	
	public void move(ActionEvent event) throws IOException, RosterException, StaffException{
		initialize();
		if(patientid == null)
			invalid.setText("Please select patient id!");
		else if ( bedid == null)
			invalid.setText("Please select bed id!");
		else
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE pid = '" + patientid + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					stmt = con.createStatement();
					sql = "SELECT * FROM bed WHERE pid = '" + patientid + "';";
					ResultSet rs2 = stmt.executeQuery(sql);
					if(rs2.next()) {
						if(start.movePatientOnBed(id, patientid, bedid)) {
							invalid.setText(patientid + " move to bed " + bedid);
						}
						else
							invalid.setText("Someone on the bed!");
					}
					else
						invalid.setText("Patient not on any bed yet!");
				}
				else
					invalid.setText("Invalid patient id");
			} catch (SQLException exception) {
	            System.out.println(exception.getMessage());
	            exception.printStackTrace();
	        }
		initialize();
	}
	
	public void checkOut(ActionEvent event) throws IOException, RosterException, StaffException{
		initialize();
		if(patientid.isEmpty())
			invalid.setText("Please enter patient id and bed id!");
		else
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM bed WHERE pid = '" + patientid + "';";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					if(start.checkOutPatient(id, patientid))
						invalid.setText("Successfully checked out!");
					else
						invalid.setText("Patient not on any bed!");
				} else
					invalid.setText("Patient not on any bed!");
			} catch (SQLException exception) {
	            System.out.println(exception.getMessage());
	            exception.printStackTrace();
	        }
		initialize();
	}
}
