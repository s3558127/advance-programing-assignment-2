package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

public class PatientConfigurationPage {
	
	@FXML
	private TextField medicineText;
	@FXML
	private TextField timeText;
	@FXML
	private TextField doseText;
	@FXML
	private TextField prescriptionText;
	@FXML
	private Label patientid;
	@FXML
	private Label username;
	@FXML
	private Label firstname;
	@FXML
	private Label lastname;
	@FXML
	private Label gender;
	@FXML
	private Label medicine;
	@FXML
	private Label prescription;
	@FXML
	private Button checkButton;
	@FXML
	private Button setMedicineButton;
	@FXML
	private Button setPrescriptionButton;
	@FXML
	private Label invalid;
	@FXML 
	private ChoiceBox<String> patientBox;
	ArrayList<String> patientList = new ArrayList<String>();
	ObservableList<String> patientsList;
	private String pidText = null;
	
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	
	String targetPatient = null;
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
    	
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM patient;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String pid = rs.getString("pid");
				patientList.add(pid);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		patientsList = FXCollections.observableArrayList(patientList);
		patientBox.setItems(patientsList);
		patientBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!patientBox.getValue().isEmpty())
                pidText = patientBox.getValue();
        });
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/BedViewPage.fxml");
	}
	
	@FXML
	public String check(ActionEvent event) throws IOException{
		invalid.setText("");
		if(pidText==null)
			invalid.setText("Please select patient id!");
		else
			try {
				stmt = con.createStatement();
				String sql = "SELECT * FROM patient WHERE pid = '" + pidText + "'";
				ResultSet rs = stmt.executeQuery(sql);
				if(rs.next()) {
					patientid.setText(rs.getString("pid"));
					username.setText(rs.getString("username"));
					firstname.setText(rs.getString("firstname"));
					lastname.setText(rs.getString("lastname"));
					gender.setText(rs.getString("gender"));
					targetPatient = rs.getString("pid");
				
					String f = "";
					prescription.setText("No prescription assigned!");
					stmt = con.createStatement();
					sql = "SELECT * FROM prescription WHERE pid = '" + targetPatient + "'";
					rs = stmt.executeQuery(sql);
					while(rs.next()) {
						if (rs.getString("prescription")!=null) {
							String temp = "\n" + rs.getString("prescription");
							f = f + temp;
							prescription.setText(f);
						}
					}
				
					f = "Medicine\t\tTime\t\t\tDose";
					medicine.setText("No medicine assigned!");
					stmt = con.createStatement();
					sql = "SELECT * FROM medicine WHERE pid = '" + targetPatient + "'";
					rs = stmt.executeQuery(sql);
					while(rs.next()) {
						if (rs.getString("med")!=null) {
							String temp = "\n" + rs.getString("med") + "\t\t" + rs.getString("time") + "\t\t\t" + rs.getString("dose");
							f = f + temp;
							medicine.setText(f);
						}
					}
				} else {
					invalid.setText("Patient ID doesn't exist!");
					return null;
				}
			} catch (SQLException exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
		return targetPatient;
	}
	
	@FXML
	public void setMedicine(ActionEvent event) throws IOException, NumberFormatException, RosterException, StaffException{
		if(check(event)==null)
			invalid.setText("Please select patient id!");
		else if (medicineText.getText().isEmpty() || timeText.getText().isEmpty() || doseText.getText().isEmpty())
			invalid.setText("Please fill in the blank!");
		else {
			try {
				DateTimeFormatter strictTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss").withResolverStyle(ResolverStyle.STRICT);
				LocalTime.parse(timeText.getText(), strictTimeFormatter);
				try {
					start.setMedicine(id, targetPatient, medicineText.getText(), timeText.getText(),Integer.parseInt(doseText.getText()));
					invalid.setText("Added medicine!");
					medicineText.setText("");
					doseText.setText("");
					timeText.setText("");
				} catch (NumberFormatException e){
					invalid.setText("Only integer for dose!");
					doseText.setText("");
				}
			} catch (DateTimeParseException | NullPointerException e) {
				invalid.setText("Time format invalid! (00:00:00)");
				timeText.setText("");
		    }
		}
		check(event);
	}
	
	@FXML
	public void setPrescription(ActionEvent event) throws IOException, RosterException, StaffException{
		if(check(event)==null)
			invalid.setText("Please select patient id!");
		else if (prescriptionText.getText().isEmpty())
			invalid.setText("Please fill in the blank!");
		else if (id.charAt(0) == 'd') {
			start.setPrescription(id, targetPatient, prescriptionText.getText());
			invalid.setText("Added prescription");
			prescriptionText.setText("");
		}
		check(event);
	}
	
}