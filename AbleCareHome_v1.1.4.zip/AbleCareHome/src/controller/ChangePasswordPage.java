package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class ChangePasswordPage {
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML
	private Label invalid;
	@FXML
	private TextField oldPassword;
	@FXML
	private TextField newPassword;
	@FXML
	private Button submitButton;
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	
	String id;
	String password;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/MenuPage.fxml");
	}
	
	@FXML
	public void submit(ActionEvent event)throws IOException, RosterException, StaffException{
		try {
			if(oldPassword.getText().isEmpty() || newPassword.getText().isEmpty())
				invalid.setText("Please fill in the blank!");
			else
				if(id.equalsIgnoreCase("admin")) {
					invalid.setText("Admin password is fixed!");
					oldPassword.setText("");
					newPassword.setText("");
				}
				else if (id.charAt(0) == 'd') {
					stmt = con.createStatement();
					String sql = "SELECT * FROM doctor;";
					ResultSet rs = stmt.executeQuery(sql);
					while(rs.next()) {
						if(rs.getString("did").equalsIgnoreCase(id))
							password = rs.getString("password");
					}	
					if (oldPassword.getText().equalsIgnoreCase(password)) {
						start.setPassword(id, id, newPassword.getText());
						m.changeScene("/fxml/MainPage.fxml");
					}
					else {
						invalid.setText("Current password incorrect!");
						oldPassword.setText("");
						newPassword.setText("");
					}
				
				} else if (id.charAt(0) == 'n') {
					stmt = con.createStatement();
					String sql = "SELECT * FROM nurse;";
					ResultSet rs = stmt.executeQuery(sql);
					while(rs.next()) {
						if(rs.getString("nid").equalsIgnoreCase(id))
							password = rs.getString("password");
					}	
					if (oldPassword.getText().equalsIgnoreCase(password)) {
						start.setPassword(id, id, newPassword.getText());
						m.changeScene("/fxml/MainPage.fxml");
					}
					else {
						invalid.setText("Current password incorrect!");
						oldPassword.setText("");
						newPassword.setText("");
					}
				}else
					invalid.setText("ID not found!");
			} catch (SQLException exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
	}
}
