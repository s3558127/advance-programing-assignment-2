package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class AddStaffPage {
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML
	private Label invalid;
	@FXML
	private TextField username;
	@FXML
	private TextField password;
	@FXML
	private Button addStaffButton;
	@FXML 
	private ChoiceBox<String> typeBox;
	@FXML 
	private ChoiceBox<String> shiftBox;
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	ArrayList<String> timeList = new ArrayList<String>();
	ObservableList<String> typeList = FXCollections.observableArrayList("doctor", "nurse");
	ObservableList<String> shiftList;
	
	String id;
	String type;
	String shift;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
    
    @FXML
	public void initialize() throws IOException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		
		try {
			stmt = con.createStatement();
			String sql = "SELECT * FROM shift;";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				String sid = rs.getString("sid");
				String starttime = rs.getString("starttime");
				String endtime = rs.getString("endtime");
				String time = sid + ": " + starttime + " to " + endtime;
				timeList.add(time);
			}
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
		shiftList = FXCollections.observableArrayList(timeList);
		typeBox.setItems(typeList);
		shiftBox.setItems(shiftList);
		typeBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!typeBox.getValue().isEmpty())
                type = Character.toString(typeBox.getValue().charAt(0));
        });
		shiftBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!shiftBox.getValue().isEmpty())
                shift = shiftBox.getValue();
        });
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/MenuPage.fxml");
	}
	
	@FXML
	public void addStaff(ActionEvent event) throws IOException, RosterException, StaffException{
		String shiftid = null;
		for (int i=0; i<shiftList.size();i++)
			if(shiftList.get(i).equalsIgnoreCase(shiftBox.getValue()))
				shiftid = "s" + Integer.toString(i);
		if(username.getText().isEmpty() || password.getText().isEmpty() || typeBox.getValue() == null|| shiftid==null) 
			invalid.setText("Please fill in the blank!");
		else if (typeBox.getValue().equalsIgnoreCase("doctor")){
			if(start.addDoctor(id, username.getText(),password.getText(),shiftid)) {
				invalid.setText("Successful added doctor!");
				username.setText("");
				password.setText("");
			} else {
				System.out.println("error1");
				invalid.setText("Username exist!");
				username.setText("");
				password.setText("");
			}
		} else {
			if(start.addNurse(id, username.getText(),password.getText(),shiftid)) {
				invalid.setText("Successful added nurse!");
				username.setText("");
				password.setText("");
			} else {
				System.out.println("error2");
				invalid.setText("Username exist!");
				username.setText("");
				password.setText("");
			}
		}
	}
	
	
}
