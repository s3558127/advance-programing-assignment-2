package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.*;
import app.*;
import model.*;
import java.io.*;
import java.sql.*;

public class AddPatientPage {
	
	@FXML
	ApplicationMain start = new ApplicationMain();
	@FXML
	Main m = new Main();
	@FXML 
	private ChoiceBox<String> genderBox;
	@FXML
	private Button back;
	@FXML
	private Button addPatientButton;
	@FXML
	private TextField firstname;
	@FXML
	private TextField lastname;
	@FXML
	private TextField username;
	@FXML
	private Label invalid;
	
	ObservableList<String> genderList = FXCollections.observableArrayList("Female", "Male");
	
	char gender;
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
	@FXML
	public void initialize() throws IOException{
		genderBox.setItems(genderList);
		genderBox.valueProperty().addListener((observableValue, s, t1) -> {
            if (!genderBox.getValue().isEmpty())
                gender = genderBox.getValue().charAt(0);
        });
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
	}
	
	@FXML
	public void back(ActionEvent event) throws IOException{
		start.printLog();
		m.changeScene("/fxml/MenuPage.fxml");
	}
	
	@FXML
	public void addPatient(ActionEvent event) throws IOException, StaffException, RosterException{
		if(lastname.getText().isEmpty() || firstname.getText().isEmpty() || genderBox.getValue() == null|| username.getText().isEmpty()) 
			invalid.setText("Please fill in the blank!");
		else {
			if(start.addPatient(id, firstname.getText(), lastname.getText(), username.getText(), gender)) {
				invalid.setText("Successful added patient!");
				lastname.setText("");
				username.setText("");
				firstname.setText("");
			}
			else {
				invalid.setText("Username exist!!");
				lastname.setText("");
				username.setText("");
				firstname.setText("");
			}
		}
	}
	
}
