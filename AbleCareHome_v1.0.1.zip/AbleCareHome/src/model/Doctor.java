package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Doctor implements StaffDetail{

	private String username;
	private String password;
	private String id;

	private ArrayList<Shift> shiftList;
	
	public Doctor(String id, String un) {
		this.id = id;
		this.username = un;
		shiftList = new ArrayList<Shift>();
	}
	
	public String getName() {
		return username;
	}

	public void setName(String name) {
		this.username = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public void setShiftList(ArrayList<Shift> shiftList) {
		this.shiftList = shiftList;
	}
	
	public ArrayList<Shift> getShiftList() {
		return this.shiftList;
	}
	
	@Override
	public void displayId() {
		System.out.println(getId());
	}
	
	@Override
	public void displayPassword() {
		System.out.println(getPassword());
	}
	
	@Override
	public void displayShift() {
		Iterator<Shift> shiftIterator = shiftList.iterator();
		while (shiftIterator.hasNext()) {
			System.out.println(shiftIterator.next().getStartTime() + "to" + shiftIterator.next().getEndTime());
		}
	}

}
