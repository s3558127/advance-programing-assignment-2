package model;

public class Bed {
	
	private String bedid;
	private Patient patient;
	private boolean bedAvailable = true;
	
	public Bed(String id) {
		this.bedid = id;
	}

	public String getBedid() {
		return bedid;
	}

	public void setBedid(String bedid) {
		this.bedid = bedid;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
		this.setBedAvailable(false);
	}

	public boolean isBedAvailable() {
		return bedAvailable;
	}

	public void setBedAvailable(boolean bedAvailable) {
		this.bedAvailable = bedAvailable;
	}
	
}
