package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.time.*;

public class ApplicationMain {
	
	private String logUpdate;
	private int patientid = 1;
	private int doctorid = 1;
	private int nurseid = 1;
	private int shiftid = 1;
	private ArrayList<Ward> wardList = new ArrayList<Ward>();
	private ArrayList<String> logList = new ArrayList<String>();
	private ArrayList<Shift> shiftList = new ArrayList<Shift>();
	
	HashMap<String,Bed> bedCheck = new HashMap<String,Bed>();
	HashMap<String,Doctor> doctors = new HashMap<String,Doctor>();
	HashMap<String,Nurse> nurses = new HashMap<String,Nurse>();
	HashMap<String,Patient> patients = new HashMap<String,Patient>();
	
	// add manager
	public void setManager(String username, String password) {
		Manager m = new Manager(username, password);
	}
	
	// add patient
	public void addPatient(String loginid, String firstname, String lastname, String username, char gender){
		if (checkDoctorLogin(loginid) || checkNurseLogin(loginid) || checkManagerLogin(loginid)){
			Patient p = new Patient("p"+patientid,firstname,lastname,username,gender);
			patients.put("p"+patientid, p);
			logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new patient p" + patientid;
			logList.add(logUpdate);
			patientid++;
		} else {
			System.out.println("Only staff has the permission!");
		}
	}
	
	// add doctor
	public void addDoctor(String loginid, String username){
		if (checkManagerLogin(loginid)){
			Doctor d = new Doctor("d"+doctorid,username);
			doctors.put("d"+doctorid, d);
			logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new doctor d" + doctorid;
			logList.add(logUpdate);
			doctorid++;
		} else {
			System.out.println("Only manager has the permission!");
		}
	}
	
	// add nurse
	public void addNurse(String loginid, String username){
		if (checkManagerLogin(loginid)){
			Nurse n = new Nurse("n"+nurseid,username);
			nurses.put("n"+nurseid, n);
			logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new nurse n" + nurseid;
			logList.add(logUpdate);
			nurseid++;
		} else {
			System.out.println("Only manager has the permission!");
		}
	}
	
	// set password of staff
	public void setPassword(String loginid, String id, String password) {
		if (checkManagerLogin(loginid)){
			if (Character.toString(id.charAt(0)).equalsIgnoreCase("d")) {
				doctors.get(id).setPassword(password);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " setting password for doctor " + id;
				logList.add(logUpdate);
			} else if (Character.toString(id.charAt(0)).equalsIgnoreCase("n")) {
				nurses.get(id).setPassword(password);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " setting password for nurse " + id;
				logList.add(logUpdate);
			} else {
				System.out.println("You are not staff!");
			}
		} else {
			System.out.println("Only manager has the permission!");
		}
	}
	
	// add shift
	public void addShift(String loginid, String starttime, String endtime) {
		if (checkManagerLogin(loginid)){
			Shift s = new Shift("s" + shiftid, starttime, endtime);
			shiftList.add(s);
			logUpdate = LocalDateTime.now() + "\t" + loginid + " adding new shift " + starttime + " to "+ endtime;
			logList.add(logUpdate);
			shiftid++;
		} else {
			System.out.println("Only manager has the permission!");
		}
	}
	
	// set shift
	public void setShift(String loginid, String id, Shift s) {
		if (checkManagerLogin(loginid)){
			ArrayList<Shift> shiftTemp = new ArrayList<Shift>();
			if (Character.toString(id.charAt(0)).equalsIgnoreCase("d")) {
				shiftTemp = doctors.get(id).getShiftList();
				shiftTemp.add(s);
				doctors.get(id).setShiftList(shiftTemp);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " setting shift " + s.getStartTime() + " to "+ s.getEndTime() + " for doctor " + id;
				logList.add(logUpdate);
			} else if (Character.toString(id.charAt(0)).equalsIgnoreCase("n")) {
				shiftTemp = nurses.get(id).getShiftList();
				shiftTemp.add(s);
				nurses.get(id).setShiftList(shiftTemp);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " setting shift " + s.getStartTime() + " to "+ s.getEndTime() + " for nurse " + id;
				logList.add(logUpdate);
			} else {
				System.out.println("You are not manager!");
			}
		} else {
			System.out.println("Only manager has the permission!");
		}
	}
	
	// move patient on bed
	public void movePatientOnBed(String loginid, String id, String bedid) {
		boolean initialBed = false;
		if (checkDoctorLogin(loginid) || checkNurseLogin(loginid) || checkManagerLogin(loginid)){
			if (patients.containsKey(id) && bedCheck.get(bedid).isBedAvailable()) {
				Iterator<Bed> bedIterator = bedCheck.values().iterator();
				while (bedIterator.hasNext()) {
					if (bedIterator.next().getPatient().equals(patients.get(id))) {
						bedIterator.next().setPatient(null);
						bedIterator.next().setBedAvailable(true);
						initialBed = true;
						putPatientOnBed(loginid,id,bedid);
					}
				}
				if (!initialBed)
					System.out.println("Patient not on any bed!");
			} else {
				System.out.println("Patient or Bed is not available!");
			}
		} else {
			System.out.println("Only staff has the permission!");
		}
	}
	
	// put patient on bed
	public void putPatientOnBed(String loginid, String id, String bedid) {
		if (checkDoctorLogin(loginid) || checkNurseLogin(loginid) || checkManagerLogin(loginid)){
			if (bedCheck.get(bedid).isBedAvailable() && patients.containsKey(id)) {
				bedCheck.get(bedid).setPatient(patients.get(id));
				logUpdate = LocalDateTime.now() + "\t" + loginid + " move patient " + id + " to bed" + bedid;
				logList.add(logUpdate);
			} else if (!patients.containsKey(id)){
				System.out.println("Patient ID is not available!");
			} else {
				System.out.println("Bed is occupied!");
			}
		} else {
			System.out.println("Only staff has the permission!");
		}
	}
	
	// check patient on bed
	public void getBedPatientDetails(String loginid, String id) {
		if (checkDoctorLogin(loginid) || checkNurseLogin(loginid) || checkManagerLogin(loginid)){
			if (bedCheck.containsKey(id) && bedCheck.get(id).isBedAvailable() == true) {
				System.out.println("No patient on the bed!");
			} else {
				System.out.println("ID:" + bedCheck.get(id).getPatient().getId());
				System.out.println("First Name:" + bedCheck.get(id).getPatient().getFirstname());
				System.out.println("Last Name:" + bedCheck.get(id).getPatient().getLastname());
				System.out.println("Username:" + bedCheck.get(id).getPatient().getUsername());
				System.out.println("Gender:" + bedCheck.get(id).getPatient().getGender());
				logUpdate = LocalDateTime.now() + "\t" + loginid + " checking patient " + id + " details";
				logList.add(logUpdate);
			}
		} else {
			System.out.println("Only staff has the permission!");
		}
	}
	
	// setting patient medicine
	public void setMedicine(String loginid, String id, String med, String time, int dose) {
		if (checkDoctorLogin(loginid)) {
			if (patients.containsKey(id)) {
				ArrayList<Medicine> medicineTemp = new ArrayList<Medicine>();
				medicineTemp = patients.get(id).getMedicineList();
				Medicine m = new Medicine(med, time, dose);
				medicineTemp.add(m);
				patients.get(id).setMedicineList(medicineTemp);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " setting medicine for patient " + id;
				logList.add(logUpdate);
			} else {
				System.out.println("Patient doesn't exist!");
			}
		} else {
			System.out.println("Only doctor has the permission!");
		}
	}
	
	
	// setting patient prescription
	public void setPrescription(String loginid, String id, String pres) {
		if (checkDoctorLogin(loginid)) {
			if (patients.containsKey(id)) {
				ArrayList<Prescription> prescriptionTemp = new ArrayList<Prescription>();
				prescriptionTemp = patients.get(id).getPrescriptionList();
				Prescription p = new Prescription(pres);
				prescriptionTemp.add(p);
				patients.get(id).setPrescriptionList(prescriptionTemp);
				logUpdate = LocalDateTime.now() + "\t" + loginid + " setting prescription for patient " + id;
				logList.add(logUpdate);
			} else {
				System.out.println("Patient doesn't exist!");
			}
		} else {
			System.out.println("Only doctor has the permission!");
		}
	}
	
	// display available bed
	public void displayAllBed() {
		Iterator<String> bedIterator = bedCheck.keySet().iterator();
		Iterator<Bed> valueIterator = bedCheck.values().iterator();
		Iterator<Bed> patientIterator = bedCheck.values().iterator();
		System.out.println("Bed ID \t" + "Available \t" + "Patient ID");
		while (bedIterator.hasNext()) {
			System.out.print(bedIterator.next()+ "\t" + valueIterator.next().isBedAvailable() +"\t\t");
			if (patientIterator.next().getPatient()!=null) {
				System.out.print(patientIterator.next().getPatient().getId());
			} else {
				System.out.print("null");
			}
			System.out.println();
		}
	}
	
	// check doctor login permission
	public boolean checkDoctorLogin(String loginid) {
		if(loginid.charAt(0) == 'd')
			return true;
		else
			return false;
	}
	
	// check nurse login permission
	public boolean checkNurseLogin(String loginid) {
		if(loginid.charAt(0) == 'n')
			return true;
		else
			return false;
	}
	
	// check manager login permission
	public boolean checkManagerLogin(String loginid) {
		if(loginid.equalsIgnoreCase(loginid))
			return true;
		else
			return false;
	}
	
	// check shift
	
	
	// initialize everything
	public void initialize() {
		
		// initialize first manager
		setManager("admin","admin123");
		
		// ward, room, bed initialize
		int wardid = 1;
		for(int j = 0; j < 2; j++) {
			Ward ward = new Ward("w" + wardid);
			int roomid = 1;
			ArrayList<Room> roomList = new ArrayList<Room>();
			for(int i = 0; i < 6; i++) {
				Room room = new Room("w" + wardid+"r"+roomid);
				
				ArrayList<Bed> bedList = new ArrayList<Bed>();
				int bedid = 1;
				if(i == 0) {
					Bed beds = new Bed("w" + wardid+"r"+roomid+"b" + bedid);
					bedList.add(beds);
					bedCheck.put("w" + wardid+"r"+roomid+"b" + bedid,beds);
					bedid++;
				} else if(i == 1) {
					for(int bed = 0; bed < 2; bed++) {
						Bed beds = new Bed("w" + wardid+"r"+roomid+"b" + bedid);
						bedList.add(beds);
						bedCheck.put("w" + wardid+"r"+roomid+"b" + bedid,beds);
						bedid++;
					}
				} else {
					for(int bed = 0; bed < 4; bed++) {
						Bed beds = new Bed("w" + wardid+"r"+roomid+"b" + bedid);
						bedList.add(beds);
						bedCheck.put("w" + wardid+"r"+roomid+"b" + bedid,beds);
						bedid++;
					}
				}
				room.setBed(bedList);
				roomList.add(room);
				roomid++;
			}
			ward.setRoomList(roomList);
			wardList.add(ward);
			wardid++;
		}
		
		// compulsory shift initialize
		addShift("admin","8:00:00","16:00:00");
		addShift("admin","14:00:00","22:00:00");
	}
	
	
	public static void main(String[] args) {
		
		ApplicationMain start = new ApplicationMain();
		start.initialize();
		start.displayAllBed();
	}
}
