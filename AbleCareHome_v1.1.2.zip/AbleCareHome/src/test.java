import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import model.*;


class test {

	private ApplicationMain m;
	
	@BeforeEach
	public void setUp() throws Exception{
		m = new ApplicationMain();
	}
	
	@Test
	void exceptionTesting1() throws StaffException {
		Throwable exception = assertThrows(StaffException.class, () -> m.addShift("d1","00:00:00","23:59:59"));
	    assertEquals("Not manager!", exception.getMessage());
	}
	
	@Test
	void exceptionTesting2() throws RosterException {
		Throwable exception = assertThrows(RosterException.class, () -> m.setMedicine("d3", "p1" ,"med","23:59:59", 2));
	    assertEquals("Not shift yet!", exception.getMessage());
	}

	@Test
	void exceptionTesting3() throws RosterException {
		Throwable exception = assertThrows(RosterException.class, () -> m.setMedicine("d4", "p1" ,"med","23:59:59", 1));
	    assertEquals("Not shift yet!", exception.getMessage());
	}
	
	@Test
	void checkTesting1() throws RosterException, StaffException {
		m.addShift("admin", "00:00:00", "24:59:59");
		boolean result = 
				m.addDoctor("admin", "d1", "d1", "s1");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting2() throws RosterException, StaffException {
		m.addShift("admin", "00:00:00", "24:59:59");
		boolean result = m.addNurse("admin", "n1", "n1", "s1");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting3() throws RosterException, StaffException {
		boolean result = m.addPatient("d2", "p5", "p5", "p5", 'f');
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting4() throws RosterException, StaffException {
		m.addShift("admin", "00:00:00", "24:59:59");
		m.addNurse("admin", "n1", "n1", "s1");
		boolean result = m.setPassword("admin", "n1", "12345");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting5() throws RosterException, StaffException {
		m.addPatient("admin", "p5", "p5", "p5", 'f');
		boolean result = m.putPatientOnBed("admin", "p5", "w1r5b1");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting6() throws RosterException, StaffException {
		boolean result = m.movePatientOnBed("admin", "p1", "w1r6b2");
		assertEquals(true, result);
	}
	
}
