Requirment to run program
1. Use mysql
Database url: jdbc:mysql://localhost:3306/ablecarehome
username: root
password: admin
2. run the given ablecarehomesql_v1.0.sql to initialize tables
3. Import javafx, IDE JAVA SE 14, Scene builder
4. For manager username and password is both admin, admin
5. For patient id, always start with p (e.g. p1, p32, p500)
6. For nurse id, always start with n (e.g. n1, n32, n500)
7. For doctor id, always start with d (e.g. d1, d32, d500)
7. For shift id, always start with s (e.g. s1, s32, s500)
9. Adding shift allows you to add more shift into database, but setting shift allows you to assign shift to staff
