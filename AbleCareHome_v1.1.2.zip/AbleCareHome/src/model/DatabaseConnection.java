package model;

import java.sql.*;

/**
 * Class to create connection to a MySQL database
 */
public class DatabaseConnection {
    String url = "jdbc:mysql://localhost:3306/ablecarehome";
    String uName = "root";
    String passWord = "admin";

    public Connection connect() {
        try {
            Connection con = DriverManager.getConnection(url, uName, passWord);
            return con;
        } catch (SQLException err) {
            System.out.println(err.getMessage());
        }
        return null;
    }

}