package model;

public class RosterException extends Exception{
	
	public RosterException(String errorMessage) {
		super(errorMessage);
	}
}
