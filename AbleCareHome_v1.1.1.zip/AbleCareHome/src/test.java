import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

import model.*;

class test {

	private ApplicationMain m;
	
	@BeforeEach
	public void setUp() throws Exception{
		m = new ApplicationMain();
	}
	
	@Test
	void exceptionTesting1() throws StaffException {
		Throwable exception = assertThrows(IllegalArgumentException.class, () -> m.addShift("d1","00:00:00","23:59:59"));
	    assertEquals("Must be manager!", exception.getMessage());
	}

	@Test
	void exceptionTesting2() throws StaffException {
		Throwable exception = assertThrows(IllegalArgumentException.class, () -> m.setMedicine("d1","ex","ex","ex",1));
	    assertEquals("Must be doctor!", exception.getMessage());
	}
	
	@Test
	void exceptionTesting3() throws RosterException {
		Throwable exception = assertThrows(IllegalArgumentException.class, () -> m.setMedicine("d2","ex","ex","ex",1));
	    assertEquals("Not shift yet!", exception.getMessage());
	}
	
	@Test
	void checkTesting1() throws RosterException, StaffException {
		m.addShift("admin", "00:00:00", "24:59:59");
		boolean result = m.addDoctor("admin", "d1", "d1", "s1");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting2() throws RosterException, StaffException {
		m.addShift("admin", "00:00:00", "24:59:59");
		boolean result = m.addNurse("admin", "n1", "n1", "s1");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting3() throws RosterException, StaffException {
		boolean result = m.addPatient("admin", "p1", "p1", "p1", 'f');
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting4() throws RosterException, StaffException {
		m.addShift("admin", "00:00:00", "24:59:59");
		m.addNurse("admin", "n1", "n1", "s1");
		boolean result = m.setPassword("admin", "n1", "12345");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting5() throws RosterException, StaffException {
		m.addPatient("admin", "p1", "p1", "p1", 'f');
		boolean result = m.putPatientOnBed("admin", "p1", "w1r1b1");
		assertEquals(true, result);
	}
	
	@Test
	void checkTesting6() throws RosterException, StaffException {
		m.addPatient("admin", "p1", "p1", "p1", 'f');
		m.putPatientOnBed("admin", "p1", "w1r1b1");
		boolean result = m.movePatientOnBed("admin", "p1", "w1r1b2");
		assertEquals(true, result);
	}
}
