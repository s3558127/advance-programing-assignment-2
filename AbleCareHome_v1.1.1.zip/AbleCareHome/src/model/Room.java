package model;

import java.util.ArrayList;

public class Room {
	
	private String roomid;
	
	private ArrayList<Bed> bedList;
	
	public Room(String id) {
		this.roomid = id;
		bedList = new ArrayList<Bed>();
	}

	public String getRoomid() {
		return roomid;
	}

	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}

	public ArrayList<Bed> getBed() {
		return bedList;
	}

	public void setBed(ArrayList<Bed> bed) {
		this.bedList = bed;
	}
	
}
