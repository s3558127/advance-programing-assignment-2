package model;

import java.util.ArrayList;

public class Ward {
	
	private String wardid;
	
	ArrayList<Room> roomList;
	
	public Ward(String id) {
		this.wardid = id;
		roomList = new ArrayList<Room>();
	}

	public ArrayList<Room> getRoomList() {
		return roomList;
	}

	public void setRoomList(ArrayList<Room> roomList) {
		this.roomList = roomList;
	}
}
