package app;

import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;
import java.io.IOException;
import model.*;
import controller.*;


public class Main extends Application {
	
	private static Stage stg;
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		 
		stg = primaryStage;
		// load the FXML file in the view package and use it as the root node
		// in the UI hierarchy
		Parent root = FXMLLoader.load(getClass().getResource("/fxml/MainPage.fxml"));
		
		// create a scene with a width and height, which can be equal to the width and height of
		// the main pane in our UI
		Scene scene = new Scene(root, 800, 600);
		
		// set the scene on the stage
		primaryStage.setScene(scene);
		
		// show the stage
		primaryStage.show();
		
	}
	
	public void changeScene(String fxml) throws IOException{
		Parent pane = FXMLLoader.load(getClass().getResource(fxml));
		stg.getScene().setRoot(pane);
	}
	
	public static void main(String[] args) throws Exception{
		Application.launch(args);
	}

}