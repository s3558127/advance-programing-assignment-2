package model;

public class Shift {
	
	private String startTime;
	private String endTime;
	private String shiftid;
	
	public Shift(String id, String st, String et) {
		this.startTime = st;
		this.endTime = et;
		this.shiftid = id;
	}
	
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public String getShiftId() {
		return shiftid;
	}

	public void setShiftId(String shiftid) {
		this.shiftid = shiftid;
	}
}
