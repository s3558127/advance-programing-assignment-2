package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import app.DatabaseConnection;
import app.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class PatientConfigurationPage {
	
	@FXML
	private Button back;
	@FXML
	Main m = new Main();
	
	String id;
	DatabaseConnection database = new DatabaseConnection();
    Connection con = database.connect();
    Statement stmt;
	
    @FXML
	public void initialize() throws IOException{
		try {
			stmt = con.createStatement();
			String sql = "SELECT loginid FROM user WHERE id = 1;";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
				id = rs.getString("loginid");
			System.out.println(id);
		} catch (SQLException exception) {
            System.out.println(exception.getMessage());
            exception.printStackTrace();
        }
	}
    
	@FXML
	public void back(ActionEvent event) throws IOException{
		m.changeScene("/fxml/BedViewPage.fxml");
	}
}